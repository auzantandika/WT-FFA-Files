# Dub-AntiCheat-FiveM
An OP anticheat that can detect most of the hacks FiveM servers. 

# Discontinued
