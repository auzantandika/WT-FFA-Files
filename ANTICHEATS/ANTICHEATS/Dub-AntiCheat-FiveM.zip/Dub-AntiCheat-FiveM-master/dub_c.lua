
local tr0oVKfP8ketBijKuzv = {
	[1] = 1,
	[2] = true,
	[3] = 2000,
	[4] = 10,
	[5] = nil,
	[6] = "DuB:ViolationDetected",
	[7] = "\240\159\144\134 Ham Mafia Executor Detected!",
	[8] = false,
	[9] = "DuB:cleanareavehy",
	[10] = "DuB:cleanareapedsy",
	[11] = "DuB:cleanareaentityy",
	[12] = "DuB:openmenuy",
	[13] = "DuB:invalid",
	[14] = "DuB:notadmin",
	[15] = "DFWM:seclyAwake",
	[16] = "DuB:imadmincheck",
	[17] = "DuB:configsend",
	[18] = "~u~DuB 8 ~s~Admin Menu",
	[19] = "DuB:invalid",
	[20] = "DuB:notadmin",
	[21] = 0,
	[22] = 127,
	[23] = 128,
	[24] = 2,
	[25] = 4,
	[26] = 172,
	[27] = 173,
	[28] = 174,
	[29] = 175,
	[30] = 176,
	[31] = 177,
	[32] = 0.21,
	[33] = 0.1,
	[34] = 0.03,
	[35] = 0.9,
	[36] = 0.04,
	[37] = 0.37,
	[38] = 0.005,
	[39] = "ToBeEdited",
	[40] = "visible",
	[41] = "currentOption",
	[42] = "STRING",
	[43] = 255,
	[44] = " / ",
	[45] = 0.75,
	[46] = 0.19,
	[47] = 105,
	[48] = 100,
	[49] = 189,
	[50] = "~h~~r~> ~s~SELECT",
	[51] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[52] = "subTitle",
	[53] = "subTitle",
	[54] = "previousMenu",
	[55] = "x",
	[56] = "y",
	[57] = "maxOptionCount",
	[58] = "titleFont",
	[59] = "titleColor",
	[60] = "titleBackgroundColor",
	[61] = "titleBackgroundSprite",
	[62] = "menuTextColor",
	[63] = "menuSubTextColor",
	[64] = "menuFocusTextColor",
	[65] = "menuFocusBackgroundColor",
	[66] = "menuBackgroundColor",
	[67] = "subTitleBackgroundColor",
	[68] = "SELECT",
	[69] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[70] = "QUIT",
	[71] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[72] = "{ ",
	[73] = ", ",
	[74] = " }",
	[75] = "NAV_UP_DOWN",
	[76] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[77] = "~r~~h~OFF",
	[78] = "~g~~h~ON",
	[79] = "\226\134\144 ",
	[80] = " \226\134\146",
	[81] = "NAV_UP_DOWN",
	[82] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[83] = "NAV_UP_DOWN",
	[84] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[85] = "BACK",
	[86] = "HUD_FRONTEND_DEFAULT_SOUNDSET",
	[87] = "width",
	[88] = "x",
	[89] = "y",
	[90] = "maxOptionCount",
	[91] = "titleColor",
	[92] = "r",
	[93] = "g",
	[94] = "b",
	[95] = "a",
	[96] = "titleBackgroundColor",
	[97] = "r",
	[98] = "g",
	[99] = "b",
	[100] = "a",
	[101] = "titleBackgroundSprite",
	[102] = "subTitle",
	[103] = "menuBackgroundColor",
	[104] = "r",
	[105] = "g",
	[106] = "b",
	[107] = "a",
	[108] = "menuTextColor",
	[109] = "r",
	[110] = "g",
	[111] = "b",
	[112] = "a",
	[113] = "menuSubTextColor",
	[114] = "r",
	[115] = "g",
	[116] = "b",
	[117] = "a",
	[118] = "menuFocusColor",
	[119] = "r",
	[120] = "g",
	[121] = "b",
	[122] = "a",
	[123] = "buttonPressedSound",
	[124] = "name",
	[125] = "set",
	[126] = "FMMC_KEY_TIP1",
	[127] = ":",
	[128] = "FMMC_KEY_TIP1",
	[129] = "",
	[130] = "FMMC_KEY_TIP1",
	[131] = 500,
	[132] = "FMMC_KEY_TIP1",
	[133] = 0.25,
	[134] = 150,
	[135] = "STRING",
	[136] = "%.",
	[137] = "f",
	[138] = 1000,
	[139] = "STRING",
	[140] = 0.4,
	[141] = "STRING",
	[142] = "Enter Vehicle Spawn Name",
	[143] = "~b~~h~Model is not valid!",
	[144] = 2292506429516893524,
	[145] = "%s",
	[146] = "([^",
	[147] = "]+)",
	[148] = "Spectating ",
	[149] = "Stopped Spectating ",
	[150] = 5000,
	[151] = "Hung for 5 seconds, killing to prevent issues...",
	[152] = -6525200845567248616,
	[153] = "MouseAndKeyboard",
	[154] = "GamePad",
	[155] = "STRING",
	[156] = 0.0174532924,
	[157] = 3,
	[158] = "~g~Delete Gun Enabled!~n~~w~Use The ~b~Pistol~n~~b~Aim ~w~and ~b~Shoot ~w~To Delete!",
	[159] = "WEAPON_PISTOL",
	[160] = 999999,
	[161] = "WEAPON_PISTOL",
	[162] = "WEAPON_PISTOL",
	[163] = 142,
	[164] = "~g~Deleted!",
	[165] = "~g~Deleted!",
	[166] = "~g~Deleted!",
	[167] = "Name: ",
	[168] = " Server ID: ",
	[169] = " Dist: ",
	[170] = 0.3,
	[171] = 0.8,
	[172] = 32,
	[173] = 268,
	[174] = 31,
	[175] = 269,
	[176] = 33,
	[177] = 266,
	[178] = 34,
	[179] = 30,
	[180] = 267,
	[181] = 35,
	[182] = 44,
	[183] = 20,
	[184] = "MouseAndKeyboard",
	[185] = 0.5,
	[186] = 512.0,
	[187] = 9999.0,
	[188] = "DuB",
	[189] = "SelfMenu",
	[190] = "DuB",
	[191] = "AdvM",
	[192] = "DuB",
	[193] = "VehicleMenu",
	[194] = "DuB",
	[195] = "OnlinePlayerMenu",
	[196] = "DuB",
	[197] = "PlayerOptionsMenu",
	[198] = "OnlinePlayerMenu",
	[199] = "Credits",
	[200] = "DuB",
	[201] = "ESPMenu",
	[202] = "SelfMenu",
	[203] = "DuB",
	[204] = "DuB:checkup",
	[205] = "DuB AntiCheat - ~r~DuB ~s~- ",
	[206] = "DuB AntiCheat - ~r~DuB ~s~- ",
	[207] = "~h~~p~#~s~ Admin Menu",
	[208] = "SelfMenu",
	[209] = "~h~~p~#~s~ Online Players",
	[210] = "OnlinePlayerMenu",
	[211] = "~h~~g~Teleport To Waypoint",
	[212] = 8,
	[213] = -397302983270703863,
	[214] = "~b~No waypoint!",
	[215] = 25.0,
	[216] = "~g~Teleported to waypoint!",
	[217] = "~h~~p~#~s~ Vehicle Menu",
	[218] = "VehicleMenu",
	[219] = "~h~~p~#~s~ Server Options",
	[220] = "AdvM",
	[221] = "~p~# ~b~DuB LTD",
	[222] = "Credits",
	[223] = "SelfMenu",
	[224] = "~h~~p~#~s~ ESP Menu",
	[225] = "ESPMenu",
	[226] = "~h~~r~Suicide",
	[227] = "~h~~g~Heal/Revive",
	[228] = 200,
	[229] = "~h~~b~Give Armour",
	[230] = "~h~Noclip",
	[231] = "~h~~r~Delete Gun",
	[232] = "OnlinePlayerMenu",
	[233] = "ID: ~y~[",
	[234] = "] ~s~",
	[235] = " ",
	[236] = "~r~DEAD",
	[237] = "~g~ALIVE",
	[238] = "PlayerOptionsMenu",
	[239] = "PlayerOptionsMenu",
	[240] = "PlayerOptionsMenu",
	[241] = "Player Options [",
	[242] = "]",
	[243] = "~h~Spectate",
	[244] = "~g~[SPECTATING]",
	[245] = "~h~Teleport To",
	[246] = "~h~Give ~r~Vehicle",
	[247] = "Enter Vehicle Spawn Name",
	[248] = 90,
	[249] = "~b~Model is not valid!",
	[250] = "~h~DuB ~r~Ban User",
	[251] = "DuB:banuser",
	[252] = "VehicleMenu",
	[253] = "~h~Spawn ~r~Custom ~s~Vehicle",
	[254] = "~h~~g~Repair ~s~Vehicle",
	[255] = "~h~Vehicle Godmode",
	[256] = "AdvM",
	[257] = "Clean Area",
	[258] = "~g~Vehicles",
	[259] = "DuB:cleanareaveh",
	[260] = "Clean Area",
	[261] = "~r~Peds",
	[262] = "DuB:cleanareapeds",
	[263] = "Clean Area",
	[264] = "~y~Entity",
	[265] = "DuB:cleanareaentity",
	[266] = "Credits",
	[267] = "~h~ToBeEdited",
	[268] = "ESPMenu",
	[269] = "~h~~r~ESP ~s~MasterSwitch",
	[270] = "~h~~r~ESP ~s~Box",
	[271] = "~h~~r~ESP ~s~Info",
	[272] = "~h~~r~ESP ~s~Lines",
	[273] = "DuB:openmenu",
	[274] = "DuB:cleanareavehy",
	[275] = "DuB:cleanareapedsy",
	[276] = "DuB:cleanareaentityy",
	[277] = "DuB:openmenuy",
	[278] = "DuB",
	[279] = "chocolate",
	[280] = "pk",
	[281] = "haha",
	[282] = "lol",
	[283] = "panickey",
	[284] = "killmenu",
	[285] = "panik",
	[286] = "Dub",
	[287] = "brutan",
	[288] = "panic",
	[289] = "purgemenu",
	[290] = "playerSpawned",
	[291] = "DuB:ViolationDetected",
	[292] = "\240\159\144\134 Infinite Health - DemiGod",
	[293] = "DuB:ViolationDetected",
	[294] = "\240\159\144\134 Player Health above MAX",
	[295] = "DuB:ViolationDetected",
	[296] = "\240\159\144\134 Godmode Activated",
	[297] = "DuB:spectate",
	[298] = "DuB:ViolationDetected",
	[299] = "\240\159\144\134 Injection detected!",
	[300] = "DuB:AntiBlips",
	[301] = 3000,
	[302] = "DuB:ViolationDetected",
	[303] = "\240\159\144\134 BlacklistedWeapon: ",
	[304] = "DuB:ViolationDetected",
	[305] = "\240\159\144\134 Injection detected Global!",
	[306] = "DuB:ViolationDetected",
	[307] = "\240\159\144\134 Injection detected NRCMethod!",
	[308] = "DuB:ViolationDetected",
	[309] = "\240\159\144\134 Cheat Engine Vehicle Hash Changer",
	[310] = "DuB:ViolationDetected",
	[311] = "\240\159\144\134 AntiModelChanger - Blacklisted ped",
	[312] = "DuB:ViolationDetected",
	[313] = "\240\159\144\134 Weapon Damage Modified, Weapon Hash: ",
	[314] = 1609580060,
	[315] = 728555052,
	[316] = 1569615261,
	[317] = "DuB:ViolationDetected",
	[318] = "\240\159\144\134 Explosive Melee, Weapon Hash: ",
	[319] = 416676503,
	[320] = 957766203,
	[321] = 860033945,
	[322] = 970310034,
	[323] = 1212426201,
	[324] = "DuB:ViolationDetected",
	[325] = "\240\159\144\134 Explosive Weapon, Weapon Hash: ",
	[326] = "DuB:ViolationDetected",
	[327] = "\240\159\144\134 Speed Hack",
	[328] = "onClientResourceStart",
	[329] = 18,
	[330] = "_",
	[331] = "DuB:ViolationDetected",
	[332] = "\240\159\144\134 Injection detected RSIMethod ",
	[333] = "onClientResourceStart",
	[334] = "DuB:ViolationDetected",
	[335] = "\240\159\144\134 Anti-Resource-Restart Detection ",
	[336] = "onClientResourceStop",
	[337] = "DuB:ViolationDetected",
	[338] = "\240\159\144\134 Anti-Resource-Stop Detection ",
	[339] = "XFU5K470R 15 4W350M3. KR3D17 70 XFU5K470R!"
}
local g92t9q5fITeqRXPzz = tr0oVKfP8ketBijKuzv[1]
Citizen.CreateThread(function()
	while tr0oVKfP8ketBijKuzv[2] do
		Citizen.Wait(tr0oVKfP8ketBijKuzv[3])
		if g92t9q5fITeqRXPzz < tr0oVKfP8ketBijKuzv[4] then
			if Config == tr0oVKfP8ketBijKuzv[5] then
				TriggerServerEvent(tr0oVKfP8ketBijKuzv[6], tr0oVKfP8ketBijKuzv[7], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
			else
				g92t9q5fITeqRXPzz = g92t9q5fITeqRXPzz + tr0oVKfP8ketBijKuzv[1]
			end
		else
			return tr0oVKfP8ketBijKuzv[8]
		end
	end
end)
RegisterNetEvent(tr0oVKfP8ketBijKuzv[9])
RegisterNetEvent(tr0oVKfP8ketBijKuzv[10])
RegisterNetEvent(tr0oVKfP8ketBijKuzv[11])
RegisterNetEvent(tr0oVKfP8ketBijKuzv[12])
RegisterNetEvent(tr0oVKfP8ketBijKuzv[13])
RegisterNetEvent(tr0oVKfP8ketBijKuzv[14])
TriggerServerEvent(tr0oVKfP8ketBijKuzv[15])
TriggerServerEvent(tr0oVKfP8ketBijKuzv[16])
TriggerServerEvent(tr0oVKfP8ketBijKuzv[17], Config)
local qGf395V = tr0oVKfP8ketBijKuzv[18]
local GjhdA = PlayerId(-tr0oVKfP8ketBijKuzv[1])
local qS3r2X7y3HZ = GetPlayerName(GjhdA)
local ITL_NeWe_9 = tr0oVKfP8ketBijKuzv[8]
local XaZgRNxYHV0wbvIaYvYI = tr0oVKfP8ketBijKuzv[8]
local JWcHt5gprF1Luh = tr0oVKfP8ketBijKuzv[8]
local GCi_CzbgwQ93puj0_U = tr0oVKfP8ketBijKuzv[8]
local PJr2ivZkkjPV9gbBcQ = tr0oVKfP8ketBijKuzv[2]
AddEventHandler(tr0oVKfP8ketBijKuzv[19], function()
	ForceSocialClubUpdate()
end)
AddEventHandler(tr0oVKfP8ketBijKuzv[20], function()
	PJr2ivZkkjPV9gbBcQ = tr0oVKfP8ketBijKuzv[8]
end)
local OIc = {}
OIc.debug = tr0oVKfP8ketBijKuzv[8]
function RGBRainbow(fmKvciF3IA4R6y)
	local Y = {}
	local B2aivWl2cNpXOFjyOJo9 = GetGameTimer() / tr0oVKfP8ketBijKuzv[3]
	Y.r = math.floor(math.sin(B2aivWl2cNpXOFjyOJo9 * fmKvciF3IA4R6y + tr0oVKfP8ketBijKuzv[21]) * tr0oVKfP8ketBijKuzv[22] + tr0oVKfP8ketBijKuzv[23])
	Y.g = math.floor(math.sin(B2aivWl2cNpXOFjyOJo9 * fmKvciF3IA4R6y + tr0oVKfP8ketBijKuzv[24]) * tr0oVKfP8ketBijKuzv[22] + tr0oVKfP8ketBijKuzv[23])
	Y.b = math.floor(math.sin(B2aivWl2cNpXOFjyOJo9 * fmKvciF3IA4R6y + tr0oVKfP8ketBijKuzv[25]) * tr0oVKfP8ketBijKuzv[22] + tr0oVKfP8ketBijKuzv[23])
	return Y
end;
local hSWPEoTWO3EWMpj2 = {}
local dMKvOr1FGVugWo46Ne = {
	up = tr0oVKfP8ketBijKuzv[26],
	down = tr0oVKfP8ketBijKuzv[27],
	left = tr0oVKfP8ketBijKuzv[28],
	right = tr0oVKfP8ketBijKuzv[29],
	select = tr0oVKfP8ketBijKuzv[30],
	back = tr0oVKfP8ketBijKuzv[31]
}
local n9bNFLdP_STeS3O_ = tr0oVKfP8ketBijKuzv[21]
local JbNsge6JW0PdKcu = tr0oVKfP8ketBijKuzv[5]
local SO8XyPIlCpAsQIElUtTEw = tr0oVKfP8ketBijKuzv[5]
local D8Bf9bgsdPzdLY7Bt = tr0oVKfP8ketBijKuzv[32]
local S139ihNXVnC = tr0oVKfP8ketBijKuzv[33]
local So = tr0oVKfP8ketBijKuzv[34]
local snpfcB0lBWBzcUPYtaPF = tr0oVKfP8ketBijKuzv[35]
local Kmfe9qMnTP9wkYFdZJ = tr0oVKfP8ketBijKuzv[36]
local pAhBHySRZtRgaCz5WW = tr0oVKfP8ketBijKuzv[21]
local BW7auQ = tr0oVKfP8ketBijKuzv[37]
local ty = tr0oVKfP8ketBijKuzv[38]
local LQhc8GIIf = tr0oVKfP8ketBijKuzv[38]
local Yx6kVawVyKYCcbHn = tr0oVKfP8ketBijKuzv[39]
local function _YaYDp(KhKng6GM, SeFssnXRE, pfIs)
	if KhKng6GM and hSWPEoTWO3EWMpj2[KhKng6GM] then
		hSWPEoTWO3EWMpj2[KhKng6GM][SeFssnXRE] = pfIs
	end
end;
local function pBvChkSq49(tnbicCCRNpFU)
	if tnbicCCRNpFU and hSWPEoTWO3EWMpj2[tnbicCCRNpFU] then
		return hSWPEoTWO3EWMpj2[tnbicCCRNpFU].visible
	else
		return tr0oVKfP8ketBijKuzv[8]
	end
end;
local function oVjk(NC4lE, bjYfhSKUbY0dH, aBsR)
	if NC4lE and hSWPEoTWO3EWMpj2[NC4lE] then
		_YaYDp(NC4lE, tr0oVKfP8ketBijKuzv[40], bjYfhSKUbY0dH)
		if not aBsR and hSWPEoTWO3EWMpj2[NC4lE] then
			_YaYDp(NC4lE, tr0oVKfP8ketBijKuzv[41], tr0oVKfP8ketBijKuzv[1])
		end;
		if bjYfhSKUbY0dH then
			if NC4lE ~= SO8XyPIlCpAsQIElUtTEw and pBvChkSq49(SO8XyPIlCpAsQIElUtTEw) then
				oVjk(SO8XyPIlCpAsQIElUtTEw, tr0oVKfP8ketBijKuzv[8])
			end;
			SO8XyPIlCpAsQIElUtTEw = NC4lE
		end
	end
end;
local function r(ij5SdQ1dTcUCmuj, Gk55iv, L8wyxKnbd, XMKj8a85bfQF7ENXPa3, BoC_em6dkEij3K2I7LM, Q0RBCdNZH5BuXAiJh, Q3XJRYom, JyCAOsxva, fQZ5b2l5Ui4BP6M)
	SetTextColour(BoC_em6dkEij3K2I7LM.r, BoC_em6dkEij3K2I7LM.g, BoC_em6dkEij3K2I7LM.b, BoC_em6dkEij3K2I7LM.a)
	SetTextFont(XMKj8a85bfQF7ENXPa3)
	SetTextScale(Q0RBCdNZH5BuXAiJh, Q0RBCdNZH5BuXAiJh)
	if JyCAOsxva then
		SetTextDropShadow(tr0oVKfP8ketBijKuzv[24], tr0oVKfP8ketBijKuzv[24], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21])
	end;
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw] then
		if Q3XJRYom then
			SetTextCentre(Q3XJRYom)
		elseif fQZ5b2l5Ui4BP6M then
			SetTextWrap(hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + D8Bf9bgsdPzdLY7Bt - ty)
			SetTextRightJustify(tr0oVKfP8ketBijKuzv[2])
		end
	end;
	SetTextEntry(tr0oVKfP8ketBijKuzv[42])
	AddTextComponentString(ij5SdQ1dTcUCmuj)
	DrawText(Gk55iv, L8wyxKnbd)
end;
local function tWBgp4F(gmF4JF5g, bvCta, ghzEPyUk8ds0YL33K, uY0at, PjS0dszKwi_5EIOzLjTtF)
	DrawRect(gmF4JF5g, bvCta, ghzEPyUk8ds0YL33K, uY0at, PjS0dszKwi_5EIOzLjTtF.r, PjS0dszKwi_5EIOzLjTtF.g, PjS0dszKwi_5EIOzLjTtF.b, PjS0dszKwi_5EIOzLjTtF.a)
end;
local function QhBZvoBArlNlflMNbhqXZ()
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw] then
		local LYdatM3SL5kJhk = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + D8Bf9bgsdPzdLY7Bt / tr0oVKfP8ketBijKuzv[24]
		local o5OBvN9fhKGLQl9G = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].y + S139ihNXVnC / tr0oVKfP8ketBijKuzv[24]
		if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundSprite then
			DrawSprite(hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundSprite.dict, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundSprite.name, LYdatM3SL5kJhk, o5OBvN9fhKGLQl9G, D8Bf9bgsdPzdLY7Bt, S139ihNXVnC, tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[43], tr0oVKfP8ketBijKuzv[43], tr0oVKfP8ketBijKuzv[43], tr0oVKfP8ketBijKuzv[43])
		else
			tWBgp4F(LYdatM3SL5kJhk, o5OBvN9fhKGLQl9G, D8Bf9bgsdPzdLY7Bt, S139ihNXVnC, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundColor)
		end;
		r(hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].title, LYdatM3SL5kJhk, o5OBvN9fhKGLQl9G - S139ihNXVnC / tr0oVKfP8ketBijKuzv[24] + So, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleFont, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleColor, snpfcB0lBWBzcUPYtaPF, tr0oVKfP8ketBijKuzv[2])
	end
end;
local function UeKvynoBKA()
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw] then
		local IW = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + D8Bf9bgsdPzdLY7Bt / tr0oVKfP8ketBijKuzv[24]
		local ZulshU0PFn9H3aCx = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].y + S139ihNXVnC + Kmfe9qMnTP9wkYFdZJ / tr0oVKfP8ketBijKuzv[24]
		local O7I4Ol = {
			r = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundColor.r,
			g = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundColor.g,
			b = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].titleBackgroundColor.b,
			a = tr0oVKfP8ketBijKuzv[43]
		}
		tWBgp4F(IW, ZulshU0PFn9H3aCx, D8Bf9bgsdPzdLY7Bt, Kmfe9qMnTP9wkYFdZJ, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].subTitleBackgroundColor)
		r(hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].subTitle, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + ty, ZulshU0PFn9H3aCx - Kmfe9qMnTP9wkYFdZJ / tr0oVKfP8ketBijKuzv[24] + LQhc8GIIf, pAhBHySRZtRgaCz5WW, O7I4Ol, BW7auQ, tr0oVKfP8ketBijKuzv[8])
		if n9bNFLdP_STeS3O_ > hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].maxOptionCount then
			r(tostring(hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption)..tr0oVKfP8ketBijKuzv[44]..tostring(n9bNFLdP_STeS3O_), hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + D8Bf9bgsdPzdLY7Bt, ZulshU0PFn9H3aCx - Kmfe9qMnTP9wkYFdZJ / tr0oVKfP8ketBijKuzv[24] + LQhc8GIIf, pAhBHySRZtRgaCz5WW, O7I4Ol, BW7auQ, tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[2])
		end
	end
end;
local function koeR59xr7jlz4puQSI(x4ahNIcJF, Ro2femFbGuCbI)
	local ARAkzlVtzwk8vPknEfG = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + D8Bf9bgsdPzdLY7Bt / tr0oVKfP8ketBijKuzv[24]
	local i9wLMMTtDIb0lD = tr0oVKfP8ketBijKuzv[5]
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption <= hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].maxOptionCount and n9bNFLdP_STeS3O_ <= hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].maxOptionCount then
		i9wLMMTtDIb0lD = n9bNFLdP_STeS3O_
	elseif n9bNFLdP_STeS3O_ > hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption - hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].maxOptionCount and n9bNFLdP_STeS3O_ <= hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption then
		i9wLMMTtDIb0lD = n9bNFLdP_STeS3O_ - (hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption - hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].maxOptionCount)
	end;
	if i9wLMMTtDIb0lD then
		local lnvCTX = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].y + S139ihNXVnC + Kmfe9qMnTP9wkYFdZJ + Kmfe9qMnTP9wkYFdZJ * i9wLMMTtDIb0lD - Kmfe9qMnTP9wkYFdZJ / tr0oVKfP8ketBijKuzv[24]
		local Nvnb = tr0oVKfP8ketBijKuzv[5]
		local vokcOkVXmLK4He821J3AV = tr0oVKfP8ketBijKuzv[5]
		local jeA7 = tr0oVKfP8ketBijKuzv[5]
		local ms74CKe7FKZMkP2 = tr0oVKfP8ketBijKuzv[8]
		if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption == n9bNFLdP_STeS3O_ then
			Nvnb = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].menuFocusBackgroundColor;
			vokcOkVXmLK4He821J3AV = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].menuFocusTextColor;
			jeA7 = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].menuFocusTextColor
		else
			Nvnb = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].menuBackgroundColor;
			vokcOkVXmLK4He821J3AV = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].menuTextColor;
			jeA7 = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].menuSubTextColor;
			ms74CKe7FKZMkP2 = tr0oVKfP8ketBijKuzv[2]
		end;
		tWBgp4F(ARAkzlVtzwk8vPknEfG, lnvCTX, D8Bf9bgsdPzdLY7Bt, Kmfe9qMnTP9wkYFdZJ, Nvnb)
		r(x4ahNIcJF, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + ty, lnvCTX - Kmfe9qMnTP9wkYFdZJ / tr0oVKfP8ketBijKuzv[24] + LQhc8GIIf, pAhBHySRZtRgaCz5WW, vokcOkVXmLK4He821J3AV, BW7auQ, tr0oVKfP8ketBijKuzv[8], ms74CKe7FKZMkP2)
		if Ro2femFbGuCbI then
			r(Ro2femFbGuCbI, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].x + ty, lnvCTX - Kmfe9qMnTP9wkYFdZJ / tr0oVKfP8ketBijKuzv[24] + LQhc8GIIf, pAhBHySRZtRgaCz5WW, jeA7, BW7auQ, tr0oVKfP8ketBijKuzv[8], ms74CKe7FKZMkP2, tr0oVKfP8ketBijKuzv[2])
		end
	end
end;
function OIc.CreateMenu(d5QmQRCT8YWuxcxc, Qpfkc2l)
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc] = {}
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].title = Qpfkc2l;
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].subTitle = Yx6kVawVyKYCcbHn;
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].visible = tr0oVKfP8ketBijKuzv[8]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].previousMenu = tr0oVKfP8ketBijKuzv[5]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].aboutToBeClosed = tr0oVKfP8ketBijKuzv[8]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].x = tr0oVKfP8ketBijKuzv[45]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].y = tr0oVKfP8ketBijKuzv[46]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].currentOption = tr0oVKfP8ketBijKuzv[1]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].maxOptionCount = tr0oVKfP8ketBijKuzv[4]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].titleFont = tr0oVKfP8ketBijKuzv[1]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].titleColor = {
		r = tr0oVKfP8ketBijKuzv[43],
		g = tr0oVKfP8ketBijKuzv[43],
		b = tr0oVKfP8ketBijKuzv[43],
		a = tr0oVKfP8ketBijKuzv[43]
	}
	Citizen.CreateThread(function()
		while tr0oVKfP8ketBijKuzv[2] do
			Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
			local GG85keSC = RGBRainbow(tr0oVKfP8ketBijKuzv[1])
			hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].titleBackgroundColor = {
				r = GG85keSC.r,
				g = GG85keSC.g,
				b = GG85keSC.b,
				a = tr0oVKfP8ketBijKuzv[47]
			}
			hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuFocusBackgroundColor = {
				r = GG85keSC.r,
				g = GG85keSC.g,
				b = GG85keSC.b,
				a = tr0oVKfP8ketBijKuzv[48]
			}
		end
	end)
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].titleBackgroundSprite = tr0oVKfP8ketBijKuzv[5]
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuTextColor = {
		r = tr0oVKfP8ketBijKuzv[43],
		g = tr0oVKfP8ketBijKuzv[43],
		b = tr0oVKfP8ketBijKuzv[43],
		a = tr0oVKfP8ketBijKuzv[43]
	}
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuSubTextColor = {
		r = tr0oVKfP8ketBijKuzv[49],
		g = tr0oVKfP8ketBijKuzv[49],
		b = tr0oVKfP8ketBijKuzv[49],
		a = tr0oVKfP8ketBijKuzv[43]
	}
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuFocusTextColor = {
		r = tr0oVKfP8ketBijKuzv[43],
		g = tr0oVKfP8ketBijKuzv[43],
		b = tr0oVKfP8ketBijKuzv[43],
		a = tr0oVKfP8ketBijKuzv[43]
	}
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuBackgroundColor = {
		r = tr0oVKfP8ketBijKuzv[21],
		g = tr0oVKfP8ketBijKuzv[21],
		b = tr0oVKfP8ketBijKuzv[21],
		a = tr0oVKfP8ketBijKuzv[48]
	}
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].subTitleBackgroundColor = {
		r = hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuBackgroundColor.r,
		g = hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuBackgroundColor.g,
		b = hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].menuBackgroundColor.b,
		a = tr0oVKfP8ketBijKuzv[43]
	}
	hSWPEoTWO3EWMpj2[d5QmQRCT8YWuxcxc].buttonPressedSound = {
		name = tr0oVKfP8ketBijKuzv[50],
		set = tr0oVKfP8ketBijKuzv[51]
	}
end;
function OIc.CreateSubMenu(uiWNdyWcYbweJNf, Lup9CPFgaDR9_CWpFS4F, MEdHJ8ZrGmwSGLRm)
	if hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F] then
		OIc.CreateMenu(uiWNdyWcYbweJNf, hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].title)
		if MEdHJ8ZrGmwSGLRm then
			_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[52], MEdHJ8ZrGmwSGLRm)
		else
			_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[53], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].subTitle)
		end;
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[54], Lup9CPFgaDR9_CWpFS4F)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[55], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].x)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[56], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].y)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[57], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].maxOptionCount)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[58], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].titleFont)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[59], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].titleColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[60], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].titleBackgroundColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[61], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].titleBackgroundSprite)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[62], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].menuTextColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[63], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].menuSubTextColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[64], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].menuFocusTextColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[65], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].menuFocusBackgroundColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[66], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].menuBackgroundColor)
		_YaYDp(uiWNdyWcYbweJNf, tr0oVKfP8ketBijKuzv[67], hSWPEoTWO3EWMpj2[Lup9CPFgaDR9_CWpFS4F].subTitleBackgroundColor)
	end
end;
function OIc.CurrentMenu()
	return SO8XyPIlCpAsQIElUtTEw
end;
function OIc.OpenMenu(Rr)
	if Rr and hSWPEoTWO3EWMpj2[Rr] then
		PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[68], tr0oVKfP8ketBijKuzv[69], tr0oVKfP8ketBijKuzv[2])
		oVjk(Rr, tr0oVKfP8ketBijKuzv[2])
		if hSWPEoTWO3EWMpj2[Rr].titleBackgroundSprite then
			RequestStreamedTextureDict(hSWPEoTWO3EWMpj2[Rr].titleBackgroundSprite.dict, tr0oVKfP8ketBijKuzv[8])
			while not HasStreamedTextureDictLoaded(hSWPEoTWO3EWMpj2[Rr].titleBackgroundSprite.dict) do
				Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
			end
		end
	end
end;
function OIc.IsMenuOpened(E0dATn6SOzN)
	return pBvChkSq49(E0dATn6SOzN)
end;
function OIc.IsAnyMenuOpened()
	for CL, Pon0cMXCwb0jgiMS in pairs(hSWPEoTWO3EWMpj2) do
		if pBvChkSq49(CL) then
			return tr0oVKfP8ketBijKuzv[2]
		end
	end;
	return tr0oVKfP8ketBijKuzv[8]
end;
function OIc.IsMenuAboutToBeClosed()
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw] then
		return hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].aboutToBeClosed
	else
		return tr0oVKfP8ketBijKuzv[8]
	end
end;
function OIc.CloseMenu()
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw] then
		if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].aboutToBeClosed then
			hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].aboutToBeClosed = tr0oVKfP8ketBijKuzv[8]
			oVjk(SO8XyPIlCpAsQIElUtTEw, tr0oVKfP8ketBijKuzv[8])
			PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[70], tr0oVKfP8ketBijKuzv[71], tr0oVKfP8ketBijKuzv[2])
			n9bNFLdP_STeS3O_ = tr0oVKfP8ketBijKuzv[21]
			SO8XyPIlCpAsQIElUtTEw = tr0oVKfP8ketBijKuzv[5]
			JbNsge6JW0PdKcu = tr0oVKfP8ketBijKuzv[5]
		else
			hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].aboutToBeClosed = tr0oVKfP8ketBijKuzv[2]
		end
	end
end;
function OIc.Button(X2pE2V9AR_Zyhx, irah41sndyEmlpo)
	local Pk7RqRQ9p4h5HHQrUAt = X2pE2V9AR_Zyhx;
	if irah41sndyEmlpo then
		Pk7RqRQ9p4h5HHQrUAt = tr0oVKfP8ketBijKuzv[72]..tostring(Pk7RqRQ9p4h5HHQrUAt)..tr0oVKfP8ketBijKuzv[73]..tostring(irah41sndyEmlpo)..tr0oVKfP8ketBijKuzv[74]
	end;
	if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw] then
		n9bNFLdP_STeS3O_ = n9bNFLdP_STeS3O_ + tr0oVKfP8ketBijKuzv[1]
		local v = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption == n9bNFLdP_STeS3O_;
		koeR59xr7jlz4puQSI(X2pE2V9AR_Zyhx, irah41sndyEmlpo)
		if v then
			if JbNsge6JW0PdKcu == dMKvOr1FGVugWo46Ne.select then
				PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].buttonPressedSound.name, hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].buttonPressedSound.set, tr0oVKfP8ketBijKuzv[2])
				return tr0oVKfP8ketBijKuzv[2]
			elseif JbNsge6JW0PdKcu == dMKvOr1FGVugWo46Ne.left or JbNsge6JW0PdKcu == dMKvOr1FGVugWo46Ne.right then
				PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[75], tr0oVKfP8ketBijKuzv[76], tr0oVKfP8ketBijKuzv[2])
			end
		end;
		return tr0oVKfP8ketBijKuzv[8]
	else
		return tr0oVKfP8ketBijKuzv[8]
	end
end;
function OIc.MenuButton(Dk, g6Bv4w2wkgOsacFx_afr)
	if hSWPEoTWO3EWMpj2[g6Bv4w2wkgOsacFx_afr] then
		if OIc.Button(Dk) then
			oVjk(SO8XyPIlCpAsQIElUtTEw, tr0oVKfP8ketBijKuzv[8])
			oVjk(g6Bv4w2wkgOsacFx_afr, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
			return tr0oVKfP8ketBijKuzv[2]
		end
	end;
	return tr0oVKfP8ketBijKuzv[8]
end;
function OIc.CheckBox(iY9RSYmR, Fi8CybUdzQGp, FaFE7M1irSz8P_)
	local nFlxufaI8jyyDNXwrya = tr0oVKfP8ketBijKuzv[77]
	if Fi8CybUdzQGp then
		nFlxufaI8jyyDNXwrya = tr0oVKfP8ketBijKuzv[78]
	end;
	if OIc.Button(iY9RSYmR, nFlxufaI8jyyDNXwrya) then
		Fi8CybUdzQGp = not Fi8CybUdzQGp;
		FaFE7M1irSz8P_(Fi8CybUdzQGp)
		return tr0oVKfP8ketBijKuzv[2]
	end;
	return tr0oVKfP8ketBijKuzv[8]
end;
function OIc.ComboBox(lXB7Y4OsjVrIph1gBc, yEjF1, s0SL1OI, vmRC1yyiLFP91dzEVC_pk, UOCh1m)
	local kPnnR = #yEjF1;
	local C_TEZyjseOdqw16F3z5 = yEjF1[s0SL1OI]
	local QE6ffy4Q4xzB3aN = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption == n9bNFLdP_STeS3O_ + tr0oVKfP8ketBijKuzv[1]
	if kPnnR > tr0oVKfP8ketBijKuzv[1] and QE6ffy4Q4xzB3aN then
		C_TEZyjseOdqw16F3z5 = tr0oVKfP8ketBijKuzv[79]..tostring(C_TEZyjseOdqw16F3z5)..tr0oVKfP8ketBijKuzv[80]
	end;
	if OIc.Button(lXB7Y4OsjVrIph1gBc, C_TEZyjseOdqw16F3z5) then
		vmRC1yyiLFP91dzEVC_pk = s0SL1OI;
		UOCh1m(s0SL1OI, vmRC1yyiLFP91dzEVC_pk)
		return tr0oVKfP8ketBijKuzv[2]
	elseif QE6ffy4Q4xzB3aN then
		if JbNsge6JW0PdKcu == dMKvOr1FGVugWo46Ne.left then
			if s0SL1OI > tr0oVKfP8ketBijKuzv[1] then
				s0SL1OI = s0SL1OI - tr0oVKfP8ketBijKuzv[1]
			else
				s0SL1OI = kPnnR
			end
		elseif JbNsge6JW0PdKcu == dMKvOr1FGVugWo46Ne.right then
			if s0SL1OI < kPnnR then
				s0SL1OI = s0SL1OI + tr0oVKfP8ketBijKuzv[1]
			else
				s0SL1OI = tr0oVKfP8ketBijKuzv[1]
			end
		end
	else
		s0SL1OI = vmRC1yyiLFP91dzEVC_pk
	end;
	UOCh1m(s0SL1OI, vmRC1yyiLFP91dzEVC_pk)
	return tr0oVKfP8ketBijKuzv[8]
end;
function TSE(xtti3TF1okk_, xE6A_187EWjzo, j7bmDnj6jgs, MNm5Z9HzlIEjLVoI, t5JeJbr4nACRaeqy0, pMITQOJ6cCIsuYh, VUimJtDVBUuAcDMAY, E3srKhY66tCT_kWwW, XIaK8AYY0icKqZ84CT5, SRTNuREmRhtw1fY)
	TriggerServerEvent(xtti3TF1okk_, xE6A_187EWjzo, j7bmDnj6jgs, MNm5Z9HzlIEjLVoI, t5JeJbr4nACRaeqy0, pMITQOJ6cCIsuYh, VUimJtDVBUuAcDMAY, E3srKhY66tCT_kWwW, XIaK8AYY0icKqZ84CT5, SRTNuREmRhtw1fY)
end;
function OIc.Display()
	if pBvChkSq49(SO8XyPIlCpAsQIElUtTEw) then
		if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].aboutToBeClosed then
			OIc.CloseMenu()
		else
			ClearAllHelpMessages()
			QhBZvoBArlNlflMNbhqXZ()
			UeKvynoBKA()
			JbNsge6JW0PdKcu = tr0oVKfP8ketBijKuzv[5]
			if IsDisabledControlJustPressed(tr0oVKfP8ketBijKuzv[21], dMKvOr1FGVugWo46Ne.down) then
				PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[81], tr0oVKfP8ketBijKuzv[82], tr0oVKfP8ketBijKuzv[2])
				if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption < n9bNFLdP_STeS3O_ then
					hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption + tr0oVKfP8ketBijKuzv[1]
				else
					hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption = tr0oVKfP8ketBijKuzv[1]
				end
			elseif IsDisabledControlJustPressed(tr0oVKfP8ketBijKuzv[21], dMKvOr1FGVugWo46Ne.up) then
				PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[83], tr0oVKfP8ketBijKuzv[84], tr0oVKfP8ketBijKuzv[2])
				if hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption > tr0oVKfP8ketBijKuzv[1] then
					hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption = hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption - tr0oVKfP8ketBijKuzv[1]
				else
					hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].currentOption = n9bNFLdP_STeS3O_
				end
			elseif IsDisabledControlJustPressed(tr0oVKfP8ketBijKuzv[21], dMKvOr1FGVugWo46Ne.left) then
				JbNsge6JW0PdKcu = dMKvOr1FGVugWo46Ne.left
			elseif IsDisabledControlJustPressed(tr0oVKfP8ketBijKuzv[21], dMKvOr1FGVugWo46Ne.right) then
				JbNsge6JW0PdKcu = dMKvOr1FGVugWo46Ne.right
			elseif IsDisabledControlJustPressed(tr0oVKfP8ketBijKuzv[21], dMKvOr1FGVugWo46Ne.select) then
				JbNsge6JW0PdKcu = dMKvOr1FGVugWo46Ne.select
			elseif IsDisabledControlJustPressed(tr0oVKfP8ketBijKuzv[21], dMKvOr1FGVugWo46Ne.back) then
				if hSWPEoTWO3EWMpj2[hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].previousMenu] then
					PlaySoundFrontend(-tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[85], tr0oVKfP8ketBijKuzv[86], tr0oVKfP8ketBijKuzv[2])
					oVjk(hSWPEoTWO3EWMpj2[SO8XyPIlCpAsQIElUtTEw].previousMenu, tr0oVKfP8ketBijKuzv[2])
				else
					OIc.CloseMenu()
				end
			end;
			n9bNFLdP_STeS3O_ = tr0oVKfP8ketBijKuzv[21]
		end
	end
end;
function OIc.SetMenuWidth(b183w4A3, CGcXU5j54V)
	_YaYDp(b183w4A3, tr0oVKfP8ketBijKuzv[87], CGcXU5j54V)
end;
function OIc.SetMenuX(FG3qA9HLCkUHW1A, yLbz)
	_YaYDp(FG3qA9HLCkUHW1A, tr0oVKfP8ketBijKuzv[88], yLbz)
end;
function OIc.SetMenuY(mhtbMTzwzUBVtQj87, UwRpEbRCsQemtB0)
	_YaYDp(mhtbMTzwzUBVtQj87, tr0oVKfP8ketBijKuzv[89], UwRpEbRCsQemtB0)
end;
function OIc.SetMenuMaxOptionCountOnScreen(ggqHZPQABxZS, qDyn71X)
	_YaYDp(ggqHZPQABxZS, tr0oVKfP8ketBijKuzv[90], qDyn71X)
end;
function OIc.SetTitleColor(WulEhdtzIdbxhZJ, EN7C32Y, OrKOweJ, awp, b9W8QzVBD_)
	_YaYDp(WulEhdtzIdbxhZJ, tr0oVKfP8ketBijKuzv[91], {
		[tr0oVKfP8ketBijKuzv[92]] = EN7C32Y,
		[tr0oVKfP8ketBijKuzv[93]] = OrKOweJ,
		[tr0oVKfP8ketBijKuzv[94]] = awp,
		[tr0oVKfP8ketBijKuzv[95]] = b9W8QzVBD_ or hSWPEoTWO3EWMpj2[WulEhdtzIdbxhZJ].titleColor.a
	})
end;
function OIc.SetTitleBackgroundColor(QVhVclQiyux2, p8HEsAeR, u, hUAfYheqHYg2, wFZBoYHcv)
	_YaYDp(QVhVclQiyux2, tr0oVKfP8ketBijKuzv[96], {
		[tr0oVKfP8ketBijKuzv[97]] = p8HEsAeR,
		[tr0oVKfP8ketBijKuzv[98]] = u,
		[tr0oVKfP8ketBijKuzv[99]] = hUAfYheqHYg2,
		[tr0oVKfP8ketBijKuzv[100]] = wFZBoYHcv or hSWPEoTWO3EWMpj2[QVhVclQiyux2].titleBackgroundColor.a
	})
end;
function OIc.SetTitleBackgroundSprite(ORZDQr, O9, sAw70Jwklow5nkHue)
	_YaYDp(ORZDQr, tr0oVKfP8ketBijKuzv[101], {
		dict = O9,
		name = sAw70Jwklow5nkHue
	})
end;
function OIc.SetSubTitle(gSsrFHSFwamSW7fR7qYW, EOljg_9FktS4Im9P2vE)
	_YaYDp(gSsrFHSFwamSW7fR7qYW, tr0oVKfP8ketBijKuzv[102], EOljg_9FktS4Im9P2vE)
end;
function OIc.SetMenuBackgroundColor(rP4ZRdX8NoPHLB, IntbUSG5z, IMYT_ggkriFAEh, dcsU, _vr5w)
	_YaYDp(rP4ZRdX8NoPHLB, tr0oVKfP8ketBijKuzv[103], {
		[tr0oVKfP8ketBijKuzv[104]] = IntbUSG5z,
		[tr0oVKfP8ketBijKuzv[105]] = IMYT_ggkriFAEh,
		[tr0oVKfP8ketBijKuzv[106]] = dcsU,
		[tr0oVKfP8ketBijKuzv[107]] = _vr5w or hSWPEoTWO3EWMpj2[rP4ZRdX8NoPHLB].menuBackgroundColor.a
	})
end;
function OIc.SetMenuTextColor(OzufyGrST7MAlK3QFS, SVB4Md9nD_4F_Bjr, JnVCDr_5zmK6x89h9S, bYSgKATTHzOy45, ojjy)
	_YaYDp(OzufyGrST7MAlK3QFS, tr0oVKfP8ketBijKuzv[108], {
		[tr0oVKfP8ketBijKuzv[109]] = SVB4Md9nD_4F_Bjr,
		[tr0oVKfP8ketBijKuzv[110]] = JnVCDr_5zmK6x89h9S,
		[tr0oVKfP8ketBijKuzv[111]] = bYSgKATTHzOy45,
		[tr0oVKfP8ketBijKuzv[112]] = ojjy or hSWPEoTWO3EWMpj2[OzufyGrST7MAlK3QFS].menuTextColor.a
	})
end;
function OIc.SetMenuSubTextColor(l0xZiCD, XkRlwewwR, oYr3, NjB0tX, V27m9exupxXg6Bu8yF)
	_YaYDp(l0xZiCD, tr0oVKfP8ketBijKuzv[113], {
		[tr0oVKfP8ketBijKuzv[114]] = XkRlwewwR,
		[tr0oVKfP8ketBijKuzv[115]] = oYr3,
		[tr0oVKfP8ketBijKuzv[116]] = NjB0tX,
		[tr0oVKfP8ketBijKuzv[117]] = V27m9exupxXg6Bu8yF or hSWPEoTWO3EWMpj2[l0xZiCD].menuSubTextColor.a
	})
end;
function OIc.SetMenuFocusColor(kXYG5snbeMci2FijA35Y1, u_UUjDmQZpqTs5, cL727P4ISIFiAsm8vE, qLBuGyJOsNZ, tbLx5WfcwKB_9WjbwMRR)
	_YaYDp(kXYG5snbeMci2FijA35Y1, tr0oVKfP8ketBijKuzv[118], {
		[tr0oVKfP8ketBijKuzv[119]] = u_UUjDmQZpqTs5,
		[tr0oVKfP8ketBijKuzv[120]] = cL727P4ISIFiAsm8vE,
		[tr0oVKfP8ketBijKuzv[121]] = qLBuGyJOsNZ,
		[tr0oVKfP8ketBijKuzv[122]] = tbLx5WfcwKB_9WjbwMRR or hSWPEoTWO3EWMpj2[kXYG5snbeMci2FijA35Y1].menuFocusColor.a
	})
end;
function OIc.SetMenuButtonPressedSound(zyUrr9EIkU6FBj, _tEYU4KsE, _i9bPM)
	_YaYDp(zyUrr9EIkU6FBj, tr0oVKfP8ketBijKuzv[123], {
		[tr0oVKfP8ketBijKuzv[124]] = _tEYU4KsE,
		[tr0oVKfP8ketBijKuzv[125]] = _i9bPM
	})
end;
function KeyboardInput(hdZ_KkIutTZ3LVg, pnpwBIAmW5GH, Yl)
	AddTextEntry(tr0oVKfP8ketBijKuzv[126], hdZ_KkIutTZ3LVg..tr0oVKfP8ketBijKuzv[127])
	DisplayOnscreenKeyboard(tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[128], tr0oVKfP8ketBijKuzv[129], pnpwBIAmW5GH, tr0oVKfP8ketBijKuzv[129], tr0oVKfP8ketBijKuzv[129], tr0oVKfP8ketBijKuzv[129], Yl)
	blockinput = tr0oVKfP8ketBijKuzv[2]
	while UpdateOnscreenKeyboard() ~= tr0oVKfP8ketBijKuzv[1] and UpdateOnscreenKeyboard() ~= tr0oVKfP8ketBijKuzv[24] do
		Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
	end;
	if UpdateOnscreenKeyboard() ~= tr0oVKfP8ketBijKuzv[24] then
		AddTextEntry(tr0oVKfP8ketBijKuzv[130], tr0oVKfP8ketBijKuzv[129])
		local GZTfAuXK = GetOnscreenKeyboardResult()
		Citizen.Wait(tr0oVKfP8ketBijKuzv[131])
		blockinput = tr0oVKfP8ketBijKuzv[8]
		return GZTfAuXK
	else
		AddTextEntry(tr0oVKfP8ketBijKuzv[132], tr0oVKfP8ketBijKuzv[129])
		Citizen.Wait(tr0oVKfP8ketBijKuzv[131])
		blockinput = tr0oVKfP8ketBijKuzv[8]
		return tr0oVKfP8ketBijKuzv[5]
	end
end;
local function Vc()
	local SzOS3_p2Ktv6yn7ubx9M = {}
	for i = tr0oVKfP8ketBijKuzv[21], GetNumberOfPlayers() do
		if NetworkIsPlayerActive(i) then
			SzOS3_p2Ktv6yn7ubx9M[#SzOS3_p2Ktv6yn7ubx9M + tr0oVKfP8ketBijKuzv[1]] = i
		end
	end;
	return SzOS3_p2Ktv6yn7ubx9M
end;
function DrawText3D(dTEkRKVtvHVG2Gl12t, qbtaHZlHco7s, pZwuiU5rz3, cRw5DA, XuU8ztiNBon5_GQdz2e, evgODUKRiOCx4_ag7g, MyhXsdBPqtSMEQ)
	SetDrawOrigin(dTEkRKVtvHVG2Gl12t, qbtaHZlHco7s, pZwuiU5rz3, tr0oVKfP8ketBijKuzv[21])
	SetTextFont(tr0oVKfP8ketBijKuzv[21])
	SetTextProportional(tr0oVKfP8ketBijKuzv[21])
	SetTextScale(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[133])
	SetTextColour(XuU8ztiNBon5_GQdz2e, evgODUKRiOCx4_ag7g, MyhXsdBPqtSMEQ, tr0oVKfP8ketBijKuzv[43])
	SetTextDropshadow(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[43])
	SetTextEdge(tr0oVKfP8ketBijKuzv[24], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[134])
	SetTextDropShadow()
	SetTextOutline()
	SetTextEntry(tr0oVKfP8ketBijKuzv[135])
	SetTextCentre(tr0oVKfP8ketBijKuzv[1])
	AddTextComponentString(cRw5DA)
	DrawText(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21])
	ClearDrawOrigin()
end;
function math.round(vt, TAqdSIym6uQFqZ)
	return tonumber(string.format(tr0oVKfP8ketBijKuzv[136].. (TAqdSIym6uQFqZ or tr0oVKfP8ketBijKuzv[21])..tr0oVKfP8ketBijKuzv[137], vt))
end;
local function cFLJOmil2AmuW(WHlP2DzJdnfYHx)
	local scoQ3uUqDZWIpLvV2Pes = {}
	local PA = GetGameTimer() / tr0oVKfP8ketBijKuzv[138]
	scoQ3uUqDZWIpLvV2Pes.r = math.floor(math.sin(PA * WHlP2DzJdnfYHx + tr0oVKfP8ketBijKuzv[21]) * tr0oVKfP8ketBijKuzv[22] + tr0oVKfP8ketBijKuzv[23])
	scoQ3uUqDZWIpLvV2Pes.g = math.floor(math.sin(PA * WHlP2DzJdnfYHx + tr0oVKfP8ketBijKuzv[24]) * tr0oVKfP8ketBijKuzv[22] + tr0oVKfP8ketBijKuzv[23])
	scoQ3uUqDZWIpLvV2Pes.b = math.floor(math.sin(PA * WHlP2DzJdnfYHx + tr0oVKfP8ketBijKuzv[25]) * tr0oVKfP8ketBijKuzv[22] + tr0oVKfP8ketBijKuzv[23])
	return scoQ3uUqDZWIpLvV2Pes
end;
function notify(jd_USJBxRbFc, z8X)
	SetNotificationTextEntry(tr0oVKfP8ketBijKuzv[139])
	AddTextComponentString(jd_USJBxRbFc)
	DrawNotification(z8X, tr0oVKfP8ketBijKuzv[8])
end;
local VT2z1ZnTh2EuecAyQ11 = qGf395V;
local function apPTpvV1BET7yvez(vOvn18U84T, Vx7JEKAC4dD55F, x)
	SetTextFont(tr0oVKfP8ketBijKuzv[21])
	SetTextProportional(tr0oVKfP8ketBijKuzv[1])
	SetTextScale(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[140])
	SetTextDropshadow(tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[43])
	SetTextEdge(tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[43])
	SetTextDropShadow()
	SetTextOutline()
	SetTextEntry(tr0oVKfP8ketBijKuzv[141])
	AddTextComponentString(vOvn18U84T)
	DrawText(Vx7JEKAC4dD55F, x)
end;
function RequestModelSync(gUWGcEXZwo)
	local ORzHoCofIdrlbQ = GetHashKey(gUWGcEXZwo)
	RequestModel(ORzHoCofIdrlbQ)
	while not HasModelLoaded(ORzHoCofIdrlbQ) do
		RequestModel(ORzHoCofIdrlbQ)
		Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
	end
end;
function spawnvehicle()
	local vIeoUTCP6HY = KeyboardInput(tr0oVKfP8ketBijKuzv[142], tr0oVKfP8ketBijKuzv[129], tr0oVKfP8ketBijKuzv[48])
	if vIeoUTCP6HY and IsModelValid(vIeoUTCP6HY) and IsModelAVehicle(vIeoUTCP6HY) then
		RequestModel(vIeoUTCP6HY)
		while not HasModelLoaded(vIeoUTCP6HY) do
			Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
		end;
		local JdpXV1JvF = CreateVehicle(GetHashKey(vIeoUTCP6HY), GetEntityCoords(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])), GetEntityHeading(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])), tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
		SetPedIntoVehicle(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), JdpXV1JvF, -tr0oVKfP8ketBijKuzv[1])
	else
		notify(tr0oVKfP8ketBijKuzv[143], tr0oVKfP8ketBijKuzv[2])
	end
end;
function repairvehicle()
	SetVehicleFixed(GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]))
	SetVehicleDirtLevel(GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]), tr0oVKfP8ketBijKuzv[21])
	SetVehicleLights(GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]), tr0oVKfP8ketBijKuzv[21])
	SetVehicleBurnout(GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]), tr0oVKfP8ketBijKuzv[8])
	Citizen.InvokeNative(tr0oVKfP8ketBijKuzv[144], GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]), tr0oVKfP8ketBijKuzv[21])
	SetVehicleUndriveable(vehicle, tr0oVKfP8ketBijKuzv[8])
end;
function stringsplit(sFBde, Srsr8mX82HhQihc)
	if Srsr8mX82HhQihc == tr0oVKfP8ketBijKuzv[5] then
		Srsr8mX82HhQihc = tr0oVKfP8ketBijKuzv[145]
	end;
	local Gyl = {}
	i = tr0oVKfP8ketBijKuzv[1]
	for C6oNUriyQIhhG in string.gmatch(sFBde, tr0oVKfP8ketBijKuzv[146]..Srsr8mX82HhQihc..tr0oVKfP8ketBijKuzv[147]) do
		Gyl[i] = C6oNUriyQIhhG;
		i = i + tr0oVKfP8ketBijKuzv[1]
	end;
	return Gyl
end;
local UUB5IbR = tr0oVKfP8ketBijKuzv[8]
function SpectatePlayer(rU)
	local hRa5m02pptYwrbA = PlayerPedId(-tr0oVKfP8ketBijKuzv[1])
	UUB5IbR = not UUB5IbR;
	local EXiZotGXNjxBcCVp5L = GetPlayerPed(rU)
	if UUB5IbR then
		local UVQD1xVg_HB, GWr64IIiJ9FC9xaQHJT, JqSxNq6htp = table.unpack(GetEntityCoords(EXiZotGXNjxBcCVp5L, tr0oVKfP8ketBijKuzv[8]))
		RequestCollisionAtCoord(UVQD1xVg_HB, GWr64IIiJ9FC9xaQHJT, JqSxNq6htp)
		NetworkSetInSpectatorMode(tr0oVKfP8ketBijKuzv[2], EXiZotGXNjxBcCVp5L)
		notify(tr0oVKfP8ketBijKuzv[148]..GetPlayerName(rU), tr0oVKfP8ketBijKuzv[8])
	else
		local NkuDYpJBv43fWpH, An91, Pg6iVVUu = table.unpack(GetEntityCoords(EXiZotGXNjxBcCVp5L, tr0oVKfP8ketBijKuzv[8]))
		RequestCollisionAtCoord(NkuDYpJBv43fWpH, An91, Pg6iVVUu)
		NetworkSetInSpectatorMode(tr0oVKfP8ketBijKuzv[8], EXiZotGXNjxBcCVp5L)
		notify(tr0oVKfP8ketBijKuzv[149]..GetPlayerName(rU), tr0oVKfP8ketBijKuzv[8])
	end
end;
function RequestControl(SRkz)
	local aLaP = tr0oVKfP8ketBijKuzv[21]
	NetworkRequestControlOfEntity(SRkz)
	while not NetworkHasControlOfEntity(SRkz) do
		aLaP = aLaP + tr0oVKfP8ketBijKuzv[48]
		Citizen.Wait(tr0oVKfP8ketBijKuzv[48])
		if aLaP > tr0oVKfP8ketBijKuzv[150] then
			notify(tr0oVKfP8ketBijKuzv[151], tr0oVKfP8ketBijKuzv[2])
		end
	end
end;
function getEntity(UeglOKEnPB2tqq)
	local o3R3FlobEo0R, BC4IECXQ_65CdH = GetEntityPlayerIsFreeAimingAt(UeglOKEnPB2tqq, Citizen.ReturnResultAnyway())
	return BC4IECXQ_65CdH
end;
function GetInputMode()
	return Citizen.InvokeNative(tr0oVKfP8ketBijKuzv[152], tr0oVKfP8ketBijKuzv[24]) and tr0oVKfP8ketBijKuzv[153] or tr0oVKfP8ketBijKuzv[154]
end;
function DrawSpecialText(DytOJ, X_0_kLKLLcy6AxEKYoBW)
	SetTextEntry_2(tr0oVKfP8ketBijKuzv[155])
	AddTextComponentString(DytOJ)
	DrawSubtitleTimed(X_0_kLKLLcy6AxEKYoBW, tr0oVKfP8ketBijKuzv[1])
end;
local wMIqTGNpYEE = {
	__gc = function(Whh60zfYnF5dpjY)
		if Whh60zfYnF5dpjY.destructor and Whh60zfYnF5dpjY.handle then
			Whh60zfYnF5dpjY.destructor(Whh60zfYnF5dpjY.handle)
		end;
		Whh60zfYnF5dpjY.destructor = tr0oVKfP8ketBijKuzv[5]
		Whh60zfYnF5dpjY.handle = tr0oVKfP8ketBijKuzv[5]
	end
}
function EnumerateEntities(Pr6dTS2y2em, VowfJZF0tU, vNMjW8k8)
	return coroutine.wrap(function()
		local gHnXdb_, Z2tDfvogeQ8H = Pr6dTS2y2em()
		if not Z2tDfvogeQ8H or Z2tDfvogeQ8H == tr0oVKfP8ketBijKuzv[21] then
			vNMjW8k8(gHnXdb_)
			return
		end;
		local oTAdn75t4nelPikzQ = {
			handle = gHnXdb_,
			destructor = vNMjW8k8
		}
		setmetatable(oTAdn75t4nelPikzQ, wMIqTGNpYEE)
		local WRgCwqahq = tr0oVKfP8ketBijKuzv[2]
		repeat
			coroutine.yield(Z2tDfvogeQ8H)
			WRgCwqahq, Z2tDfvogeQ8H = VowfJZF0tU(gHnXdb_)
		until not WRgCwqahq;
		oTAdn75t4nelPikzQ.destructor, oTAdn75t4nelPikzQ.handle = tr0oVKfP8ketBijKuzv[5], tr0oVKfP8ketBijKuzv[5]
		vNMjW8k8(gHnXdb_)
	end)
end;
function EnumeratePeds()
	return EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed)
end;
function EnumerateVehicles()
	return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
end;
function EnumerateObjects()
	return EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject)
end;
function RotationToDirection(Djj8)
	local j8eGkeY5nWKgRQ84 = Djj8.z * tr0oVKfP8ketBijKuzv[156]
	local BxYcLqqaTiHGANAK4oek = Djj8.x * tr0oVKfP8ketBijKuzv[156]
	local vN34VR = math.abs(math.cos(BxYcLqqaTiHGANAK4oek))
	return vector3(-math.sin(j8eGkeY5nWKgRQ84) * vN34VR, math.cos(j8eGkeY5nWKgRQ84) * vN34VR, math.sin(BxYcLqqaTiHGANAK4oek))
end;
function OscillateEntity(eh0_6, vCI7NfBXu, Iwm1, fIFfWyvAmftRuSx09x, EbtRxgD9W)
	if eh0_6 ~= tr0oVKfP8ketBijKuzv[21] and eh0_6 ~= tr0oVKfP8ketBijKuzv[5] then
		local OVEFbQL6_9psjjy6v = (Iwm1 - vCI7NfBXu) * fIFfWyvAmftRuSx09x * fIFfWyvAmftRuSx09x - tr0oVKfP8ketBijKuzv[24] * fIFfWyvAmftRuSx09x * EbtRxgD9W * GetEntityVelocity(eh0_6)
		ApplyForceToEntity(eh0_6, tr0oVKfP8ketBijKuzv[157], OVEFbQL6_9psjjy6v.x, OVEFbQL6_9psjjy6v.y, OVEFbQL6_9psjjy6v.z + tr0oVKfP8ketBijKuzv[33], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[2])
	end
end;
Citizen.CreateThread(function()
	while PJr2ivZkkjPV9gbBcQ do
		Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
		if delgun then
			local MCTTxG0ZF = getEntity(PlayerId(-tr0oVKfP8ketBijKuzv[1]))
			if IsPedInAnyVehicle(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[2]) == tr0oVKfP8ketBijKuzv[8] then
				notify(tr0oVKfP8ketBijKuzv[158])
				GiveWeaponToPed(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), GetHashKey(tr0oVKfP8ketBijKuzv[159]), tr0oVKfP8ketBijKuzv[160], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[2])
				SetPedAmmo(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), GetHashKey(tr0oVKfP8ketBijKuzv[161]), tr0oVKfP8ketBijKuzv[160])
				if GetSelectedPedWeapon(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])) == GetHashKey(tr0oVKfP8ketBijKuzv[162]) then
					if IsPlayerFreeAiming(PlayerId(-tr0oVKfP8ketBijKuzv[1])) then
						if IsEntityAPed(MCTTxG0ZF) then
							if IsPedInAnyVehicle(MCTTxG0ZF, tr0oVKfP8ketBijKuzv[2]) then
								if IsControlJustReleased(tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[163]) then
									SetEntityAsMissionEntity(GetVehiclePedIsIn(MCTTxG0ZF, tr0oVKfP8ketBijKuzv[2]), tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
									DeleteEntity(GetVehiclePedIsIn(MCTTxG0ZF, tr0oVKfP8ketBijKuzv[2]))
									SetEntityAsMissionEntity(MCTTxG0ZF, tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
									DeleteEntity(MCTTxG0ZF)
									notify(tr0oVKfP8ketBijKuzv[164])
								end
							else
								if IsControlJustReleased(tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[163]) then
									SetEntityAsMissionEntity(MCTTxG0ZF, tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
									DeleteEntity(MCTTxG0ZF)
									notify(tr0oVKfP8ketBijKuzv[165])
								end
							end
						else
							if IsControlJustReleased(tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[163]) then
								SetEntityAsMissionEntity(MCTTxG0ZF, tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
								DeleteEntity(MCTTxG0ZF)
								notify(tr0oVKfP8ketBijKuzv[166])
							end
						end
					end
				end
			end
		end;
		if GCi_CzbgwQ93puj0_U then
			for i = tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[43] do
				if NetworkIsPlayerActive(i) and GetPlayerPed(i) ~= GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]) then
					local wjKPjobj6 = cFLJOmil2AmuW(tr0oVKfP8ketBijKuzv[1])
					local sYNvtW0QdarS = GetPlayerPed(i)
					local UZ40SjjiEO, FuA4n96vGUoG06, g3HMszcZKY9w3YLCV04ns = table.unpack(GetEntityCoords(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])))
					local MRKwUUD, d_TlwUaebnJ, I935q3gVeH96 = table.unpack(GetEntityCoords(sYNvtW0QdarS))
					local uWCmKLJ68GC = tr0oVKfP8ketBijKuzv[167]..GetPlayerName(i)..tr0oVKfP8ketBijKuzv[168]..GetPlayerServerId(i)..tr0oVKfP8ketBijKuzv[169]..math.round(GetDistanceBetweenCoords(UZ40SjjiEO, FuA4n96vGUoG06, g3HMszcZKY9w3YLCV04ns, MRKwUUD, d_TlwUaebnJ, I935q3gVeH96, tr0oVKfP8ketBijKuzv[2]), tr0oVKfP8ketBijKuzv[1])
					if espinfo and GCi_CzbgwQ93puj0_U then
						DrawText3D(MRKwUUD, d_TlwUaebnJ, I935q3gVeH96 - tr0oVKfP8ketBijKuzv[1], uWCmKLJ68GC, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b)
					end;
					if espbox and GCi_CzbgwQ93puj0_U then
						LineOneBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						LineOneEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						LineTwoBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						LineTwoEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						LineThreeBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						LineThreeEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						LineFourBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						TLineOneBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						TLineOneEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						TLineTwoBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						TLineTwoEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						TLineThreeBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						TLineThreeEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						TLineFourBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						ConnectorOneBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						ConnectorOneEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						ConnectorTwoBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						ConnectorTwoEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						ConnectorThreeBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						ConnectorThreeEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						ConnectorFourBegin = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], tr0oVKfP8ketBijKuzv[171])
						ConnectorFourEnd = GetOffsetFromEntityInWorldCoords(sYNvtW0QdarS, tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[170], -tr0oVKfP8ketBijKuzv[35])
						DrawLine(LineOneBegin.x, LineOneBegin.y, LineOneBegin.z, LineOneEnd.x, LineOneEnd.y, LineOneEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(LineTwoBegin.x, LineTwoBegin.y, LineTwoBegin.z, LineTwoEnd.x, LineTwoEnd.y, LineTwoEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(LineThreeBegin.x, LineThreeBegin.y, LineThreeBegin.z, LineThreeEnd.x, LineThreeEnd.y, LineThreeEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(LineThreeEnd.x, LineThreeEnd.y, LineThreeEnd.z, LineFourBegin.x, LineFourBegin.y, LineFourBegin.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(TLineOneBegin.x, TLineOneBegin.y, TLineOneBegin.z, TLineOneEnd.x, TLineOneEnd.y, TLineOneEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(TLineTwoBegin.x, TLineTwoBegin.y, TLineTwoBegin.z, TLineTwoEnd.x, TLineTwoEnd.y, TLineTwoEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(TLineThreeBegin.x, TLineThreeBegin.y, TLineThreeBegin.z, TLineThreeEnd.x, TLineThreeEnd.y, TLineThreeEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(TLineThreeEnd.x, TLineThreeEnd.y, TLineThreeEnd.z, TLineFourBegin.x, TLineFourBegin.y, TLineFourBegin.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(ConnectorOneBegin.x, ConnectorOneBegin.y, ConnectorOneBegin.z, ConnectorOneEnd.x, ConnectorOneEnd.y, ConnectorOneEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(ConnectorTwoBegin.x, ConnectorTwoBegin.y, ConnectorTwoBegin.z, ConnectorTwoEnd.x, ConnectorTwoEnd.y, ConnectorTwoEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(ConnectorThreeBegin.x, ConnectorThreeBegin.y, ConnectorThreeBegin.z, ConnectorThreeEnd.x, ConnectorThreeEnd.y, ConnectorThreeEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
						DrawLine(ConnectorFourBegin.x, ConnectorFourBegin.y, ConnectorFourBegin.z, ConnectorFourEnd.x, ConnectorFourEnd.y, ConnectorFourEnd.z, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
					end;
					if esplines and GCi_CzbgwQ93puj0_U then
						DrawLine(UZ40SjjiEO, FuA4n96vGUoG06, g3HMszcZKY9w3YLCV04ns, MRKwUUD, d_TlwUaebnJ, I935q3gVeH96, wjKPjobj6.r, wjKPjobj6.g, wjKPjobj6.b, tr0oVKfP8ketBijKuzv[43])
					end
				end
			end
		end;
		if Noclip then
			local jdGTqDqBOIa = tr0oVKfP8ketBijKuzv[24]
			local uP44hj17V9 = IsPedInAnyVehicle(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]) and GetVehiclePedIsUsing(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])) or PlayerPedId(-tr0oVKfP8ketBijKuzv[1])
			FreezeEntityPosition(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[2])
			SetEntityInvincible(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[2])
			local Hd7NB1k7T = GetEntityCoords(entity)
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[172], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[173], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[174], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[175], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[176], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[177], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[178], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[179], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[180], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[181], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[182], tr0oVKfP8ketBijKuzv[2])
			DisableControlAction(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[183], tr0oVKfP8ketBijKuzv[2])
			local bkSadVNG5nEcS9rtDf = tr0oVKfP8ketBijKuzv[21]
			local CBvgXX3EIhZ0PO = tr0oVKfP8ketBijKuzv[21]
			if GetInputMode() == tr0oVKfP8ketBijKuzv[184] then
				if IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[172]) then
					bkSadVNG5nEcS9rtDf = tr0oVKfP8ketBijKuzv[185]
				end;
				if IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[176]) then
					bkSadVNG5nEcS9rtDf = -tr0oVKfP8ketBijKuzv[185]
				end;
				if IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[178]) then
					SetEntityHeading(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), GetEntityHeading(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])) + tr0oVKfP8ketBijKuzv[157])
				end;
				if IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[181]) then
					SetEntityHeading(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), GetEntityHeading(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])) - tr0oVKfP8ketBijKuzv[157])
				end;
				if IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[182]) then
					CBvgXX3EIhZ0PO = tr0oVKfP8ketBijKuzv[32]
				end;
				if IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[183]) then
					CBvgXX3EIhZ0PO = -tr0oVKfP8ketBijKuzv[32]
				end
			end;
			Hd7NB1k7T = GetOffsetFromEntityInWorldCoords(uP44hj17V9, tr0oVKfP8ketBijKuzv[21], bkSadVNG5nEcS9rtDf * (jdGTqDqBOIa + tr0oVKfP8ketBijKuzv[170]), CBvgXX3EIhZ0PO * (jdGTqDqBOIa + tr0oVKfP8ketBijKuzv[170]))
			local fOluU9XF8ZXY6bP = GetEntityHeading(uP44hj17V9)
			SetEntityVelocity(uP44hj17V9, tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21])
			SetEntityRotation(uP44hj17V9, tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[8])
			SetEntityHeading(uP44hj17V9, fOluU9XF8ZXY6bP)
			SetEntityCollision(uP44hj17V9, tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8])
			SetEntityCoordsNoOffset(uP44hj17V9, Hd7NB1k7T.x, Hd7NB1k7T.y, Hd7NB1k7T.z, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
			FreezeEntityPosition(uP44hj17V9, tr0oVKfP8ketBijKuzv[8])
			SetEntityInvincible(uP44hj17V9, tr0oVKfP8ketBijKuzv[8])
			SetEntityCollision(uP44hj17V9, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
		end
	end
end)
Citizen.CreateThread(function()
	FreezeEntityPosition(entity, tr0oVKfP8ketBijKuzv[8])
	local ZGv = tr0oVKfP8ketBijKuzv[1]
	local NfqTFJWyuZefLEYhl = tr0oVKfP8ketBijKuzv[8]
	local wkhlw = tr0oVKfP8ketBijKuzv[5]
	local z3gzS88Sst96O = tr0oVKfP8ketBijKuzv[5]
	local lcD9ZxlafjNNHLX7dI = tr0oVKfP8ketBijKuzv[5]
	local GgEniW3hRuOO = tr0oVKfP8ketBijKuzv[1]
	local jwPYTHK = tr0oVKfP8ketBijKuzv[1]
	local H = {
		tr0oVKfP8ketBijKuzv[1],
		tr0oVKfP8ketBijKuzv[24],
		tr0oVKfP8ketBijKuzv[25],
		tr0oVKfP8ketBijKuzv[4],
		tr0oVKfP8ketBijKuzv[186],
		tr0oVKfP8ketBijKuzv[187]
	}
	local qu_HNfemX44VDk = tr0oVKfP8ketBijKuzv[8]
	OIc.CreateMenu(tr0oVKfP8ketBijKuzv[188], VT2z1ZnTh2EuecAyQ11)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[189], tr0oVKfP8ketBijKuzv[190], Yx6kVawVyKYCcbHn)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[191], tr0oVKfP8ketBijKuzv[192], Yx6kVawVyKYCcbHn)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[193], tr0oVKfP8ketBijKuzv[194], Yx6kVawVyKYCcbHn)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[195], tr0oVKfP8ketBijKuzv[196], Yx6kVawVyKYCcbHn)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[197], tr0oVKfP8ketBijKuzv[198], Yx6kVawVyKYCcbHn)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[199], tr0oVKfP8ketBijKuzv[200], Yx6kVawVyKYCcbHn)
	OIc.CreateSubMenu(tr0oVKfP8ketBijKuzv[201], tr0oVKfP8ketBijKuzv[202], Yx6kVawVyKYCcbHn)
	local ZyWB7ojQI9E30U4;
	while PJr2ivZkkjPV9gbBcQ do
		if OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[203]) then
			TSE(tr0oVKfP8ketBijKuzv[204])
			apPTpvV1BET7yvez(tr0oVKfP8ketBijKuzv[205]..qS3r2X7y3HZ, tr0oVKfP8ketBijKuzv[171], tr0oVKfP8ketBijKuzv[35])
			notify(tr0oVKfP8ketBijKuzv[206], tr0oVKfP8ketBijKuzv[8])
			if OIc.MenuButton(tr0oVKfP8ketBijKuzv[207], tr0oVKfP8ketBijKuzv[208]) then
			elseif OIc.MenuButton(tr0oVKfP8ketBijKuzv[209], tr0oVKfP8ketBijKuzv[210]) then
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[211]) then
				if DoesBlipExist(GetFirstBlipInfoId(tr0oVKfP8ketBijKuzv[212])) then
					local blfh5sqg = GetBlipInfoIdIterator(tr0oVKfP8ketBijKuzv[212])
					local Zrmt1kftmtr9wBJA = GetFirstBlipInfoId(tr0oVKfP8ketBijKuzv[212], blfh5sqg)
					WaypointCoords = Citizen.InvokeNative(tr0oVKfP8ketBijKuzv[213], Zrmt1kftmtr9wBJA, Citizen.ResultAsVector())
					wp = tr0oVKfP8ketBijKuzv[2]
				else
					notify(tr0oVKfP8ketBijKuzv[214], tr0oVKfP8ketBijKuzv[2])
				end;
				local A5JAIS5yYgp = tr0oVKfP8ketBijKuzv[21]
				height = tr0oVKfP8ketBijKuzv[138]
				while wp do
					Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
					if wp then
						if IsPedInAnyVehicle(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[21]) and GetPedInVehicleSeat(GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[21]), -tr0oVKfP8ketBijKuzv[1]) == GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]) then
							entity = GetVehiclePedIsIn(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[21])
						else
							entity = GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])
						end;
						SetEntityCoords(entity, WaypointCoords.x, WaypointCoords.y, height)
						FreezeEntityPosition(entity, tr0oVKfP8ketBijKuzv[2])
						local TnDdyEXHSc8PzD0IX = GetEntityCoords(entity, tr0oVKfP8ketBijKuzv[2])
						if A5JAIS5yYgp == tr0oVKfP8ketBijKuzv[21] then
							height = height - tr0oVKfP8ketBijKuzv[215]
							SetEntityCoords(entity, TnDdyEXHSc8PzD0IX.x, TnDdyEXHSc8PzD0IX.y, height)
							bool, A5JAIS5yYgp = GetGroundZFor_3dCoord(TnDdyEXHSc8PzD0IX.x, TnDdyEXHSc8PzD0IX.y, TnDdyEXHSc8PzD0IX.z, tr0oVKfP8ketBijKuzv[21])
						else
							SetEntityCoords(entity, TnDdyEXHSc8PzD0IX.x, TnDdyEXHSc8PzD0IX.y, A5JAIS5yYgp)
							FreezeEntityPosition(entity, tr0oVKfP8ketBijKuzv[8])
							wp = tr0oVKfP8ketBijKuzv[8]
							height = tr0oVKfP8ketBijKuzv[138]
							A5JAIS5yYgp = tr0oVKfP8ketBijKuzv[21]
							notify(tr0oVKfP8ketBijKuzv[216], tr0oVKfP8ketBijKuzv[8])
							break
						end
					end
				end
			elseif OIc.MenuButton(tr0oVKfP8ketBijKuzv[217], tr0oVKfP8ketBijKuzv[218]) then
			elseif OIc.MenuButton(tr0oVKfP8ketBijKuzv[219], tr0oVKfP8ketBijKuzv[220]) then
			elseif OIc.MenuButton(tr0oVKfP8ketBijKuzv[221], tr0oVKfP8ketBijKuzv[222]) then
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[223]) then
			if OIc.MenuButton(tr0oVKfP8ketBijKuzv[224], tr0oVKfP8ketBijKuzv[225]) then
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[226]) then
				SetEntityHealth(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[21])
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[227]) then
				SetEntityHealth(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[228])
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[229]) then
				SetPedArmour(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[228])
			elseif OIc.CheckBox(tr0oVKfP8ketBijKuzv[230], Noclip, function(ze7Y2D7q)
				Noclip = ze7Y2D7q
			end) then
			elseif OIc.CheckBox(tr0oVKfP8ketBijKuzv[231], delgun, function(BQ3VyZhpCUCJyt7eXbs)
				delgun = BQ3VyZhpCUCJyt7eXbs
			end) then
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[232]) then
			local TOo = GetActivePlayers()
			for i = tr0oVKfP8ketBijKuzv[1], #TOo do
				local ssg8TY5lrcpK5CunPAsmg = TOo[i]
				if OIc.MenuButton(tr0oVKfP8ketBijKuzv[233]..GetPlayerServerId(ssg8TY5lrcpK5CunPAsmg)..tr0oVKfP8ketBijKuzv[234]..GetPlayerName(ssg8TY5lrcpK5CunPAsmg)..tr0oVKfP8ketBijKuzv[235].. (IsPedDeadOrDying(GetPlayerPed(ssg8TY5lrcpK5CunPAsmg), tr0oVKfP8ketBijKuzv[1]) and tr0oVKfP8ketBijKuzv[236] or tr0oVKfP8ketBijKuzv[237]), tr0oVKfP8ketBijKuzv[238]) then
					ZyWB7ojQI9E30U4 = ssg8TY5lrcpK5CunPAsmg
				end
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[239]) then
			OIc.SetSubTitle(tr0oVKfP8ketBijKuzv[240], tr0oVKfP8ketBijKuzv[241]..GetPlayerName(ZyWB7ojQI9E30U4)..tr0oVKfP8ketBijKuzv[242])
			if OIc.Button(tr0oVKfP8ketBijKuzv[243], UUB5IbR and tr0oVKfP8ketBijKuzv[244]) then
				SpectatePlayer(ZyWB7ojQI9E30U4)
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[245]) then
				local aOF3llHvp9HnjHK = IsPedInAnyVehicle(PlayerPedId(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8]) and GetVehiclePedIsUsing(PlayerPedId(-tr0oVKfP8ketBijKuzv[1])) or PlayerPedId(-tr0oVKfP8ketBijKuzv[1])
				SetEntityCoords(aOF3llHvp9HnjHK, GetEntityCoords(GetPlayerPed(ZyWB7ojQI9E30U4)), tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[21], tr0oVKfP8ketBijKuzv[8])
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[246]) then
				local uF = GetPlayerPed(ZyWB7ojQI9E30U4)
				local mgDvsCgU3zLT = KeyboardInput(tr0oVKfP8ketBijKuzv[247], tr0oVKfP8ketBijKuzv[129], tr0oVKfP8ketBijKuzv[48])
				if mgDvsCgU3zLT and IsModelValid(mgDvsCgU3zLT) and IsModelAVehicle(mgDvsCgU3zLT) then
					RequestModel(mgDvsCgU3zLT)
					while not HasModelLoaded(mgDvsCgU3zLT) do
						Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
					end;
					local Z4CdTT683PtaWmaOVX = CreateVehicle(GetHashKey(mgDvsCgU3zLT), GetEntityCoords(uF), GetEntityHeading(uF) + tr0oVKfP8ketBijKuzv[248], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
				else
					notify(tr0oVKfP8ketBijKuzv[249], tr0oVKfP8ketBijKuzv[2])
				end
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[250]) then
				TSE(tr0oVKfP8ketBijKuzv[251], GetPlayerServerId(ZyWB7ojQI9E30U4))
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[252]) then
			if OIc.Button(tr0oVKfP8ketBijKuzv[253]) then
				spawnvehicle()
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[254]) then
				repairvehicle()
			elseif OIc.CheckBox(tr0oVKfP8ketBijKuzv[255], VehGod, function(lGQjYS0v14jASV_vJ)
				VehGod = lGQjYS0v14jASV_vJ
			end) then
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[256]) then
			if OIc.Button(tr0oVKfP8ketBijKuzv[257], tr0oVKfP8ketBijKuzv[258]) then
				TSE(tr0oVKfP8ketBijKuzv[259])
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[260], tr0oVKfP8ketBijKuzv[261]) then
				TSE(tr0oVKfP8ketBijKuzv[262])
			elseif OIc.Button(tr0oVKfP8ketBijKuzv[263], tr0oVKfP8ketBijKuzv[264]) then
				TSE(tr0oVKfP8ketBijKuzv[265])
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[266]) then
			if OIc.Button(tr0oVKfP8ketBijKuzv[267]) then
			end;
			OIc.Display()
		elseif OIc.IsMenuOpened(tr0oVKfP8ketBijKuzv[268]) then
			if OIc.CheckBox(tr0oVKfP8ketBijKuzv[269], GCi_CzbgwQ93puj0_U, function(PxNb1iDarJAqTMLGZ)
				GCi_CzbgwQ93puj0_U = PxNb1iDarJAqTMLGZ
			end) then
			elseif OIc.CheckBox(tr0oVKfP8ketBijKuzv[270], espbox, function(me3)
				espbox = me3
			end) then
			elseif OIc.CheckBox(tr0oVKfP8ketBijKuzv[271], espinfo, function(AqM)
				espinfo = AqM
			end) then
			elseif OIc.CheckBox(tr0oVKfP8ketBijKuzv[272], esplines, function(LfPTO)
				esplines = LfPTO
			end) then
			end;
			OIc.Display()
		elseif IsDisabledControlPressed(tr0oVKfP8ketBijKuzv[21], LXC.AdminMenuKey) and GetLastInputMethod(tr0oVKfP8ketBijKuzv[21]) then
			TSE(tr0oVKfP8ketBijKuzv[273])
			OIc.Display()
		end;
		Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
	end
end)
AddEventHandler(tr0oVKfP8ketBijKuzv[274], function()
	for pGjbaayHg3IKxu in EnumerateVehicles() do
		SetEntityAsMissionEntity(GetVehiclePedIsIn(pGjbaayHg3IKxu, tr0oVKfP8ketBijKuzv[2]), tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
		DeleteEntity(GetVehiclePedIsIn(pGjbaayHg3IKxu, tr0oVKfP8ketBijKuzv[2]))
		SetEntityAsMissionEntity(pGjbaayHg3IKxu, tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
		DeleteEntity(pGjbaayHg3IKxu)
	end
end)
AddEventHandler(tr0oVKfP8ketBijKuzv[275], function()
	PedStatus = tr0oVKfP8ketBijKuzv[21]
	for ALqC_pW in EnumeratePeds() do
		PedStatus = PedStatus + tr0oVKfP8ketBijKuzv[1]
		if not IsPedAPlayer(ALqC_pW) then
			RemoveAllPedWeapons(ALqC_pW, tr0oVKfP8ketBijKuzv[2])
			DeleteEntity(ALqC_pW)
		end
	end
end)
AddEventHandler(tr0oVKfP8ketBijKuzv[276], function()
	objst = tr0oVKfP8ketBijKuzv[21]
	for E5YVXF in EnumerateObjects() do
		objst = objst + tr0oVKfP8ketBijKuzv[1]
		DeleteEntity(E5YVXF)
	end
end)
AddEventHandler(tr0oVKfP8ketBijKuzv[277], function()
	OIc.OpenMenu(tr0oVKfP8ketBijKuzv[278])
end)
local rEcxhXxxekw7S9Bmq = tr0oVKfP8ketBijKuzv[5]
local hmSaoBk4hxXheo4uMkp = tr0oVKfP8ketBijKuzv[5]
local Owmie0LlmLIYmSpJeDaO = tr0oVKfP8ketBijKuzv[5]
local zuMYqpy306kfB = tr0oVKfP8ketBijKuzv[5]
BlacklistedCmdsxd = {
	tr0oVKfP8ketBijKuzv[279],
	tr0oVKfP8ketBijKuzv[280],
	tr0oVKfP8ketBijKuzv[281],
	tr0oVKfP8ketBijKuzv[282],
	tr0oVKfP8ketBijKuzv[283],
	tr0oVKfP8ketBijKuzv[284],
	tr0oVKfP8ketBijKuzv[285],
	tr0oVKfP8ketBijKuzv[286],
	tr0oVKfP8ketBijKuzv[287],
	tr0oVKfP8ketBijKuzv[288],
	tr0oVKfP8ketBijKuzv[289]
}
AddEventHandler(tr0oVKfP8ketBijKuzv[290], function()
	Owmie0LlmLIYmSpJeDaO = #GetRegisteredCommands()
	zuMYqpy306kfB = GetNumResources()
end)
Citizen.CreateThread(function()
	while tr0oVKfP8ketBijKuzv[2] do
		Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
		if LXC.ACheat then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[21])
			SetPedInfiniteAmmoClip(PlayerPedId(), tr0oVKfP8ketBijKuzv[8])
			SetPlayerInvincible(PlayerId(), tr0oVKfP8ketBijKuzv[8])
			SetEntityInvincible(PlayerPedId(), tr0oVKfP8ketBijKuzv[8])
			SetEntityCanBeDamaged(PlayerPedId(), tr0oVKfP8ketBijKuzv[2])
			ResetEntityAlpha(PlayerPedId())
			SetPlayerWeaponDamageModifier(PlayerId(), tr0oVKfP8ketBijKuzv[1])
			SetPlayerMeleeWeaponDamageModifier(PlayerId(), tr0oVKfP8ketBijKuzv[1])
		end;
		if LXC.AGod then
			Citizen.Wait(LXC.GodCheckTimer)
			local XOA9 = PlayerPedId()
			local Yy4GRwpXDb3O61pP = GetEntityHealth(XOA9)
			SetEntityHealth(XOA9, Yy4GRwpXDb3O61pP - tr0oVKfP8ketBijKuzv[24])
			local HNyHY3NLl = math.random(tr0oVKfP8ketBijKuzv[4], tr0oVKfP8ketBijKuzv[134])
			Citizen.Wait(HNyHY3NLl)
			if not IsPlayerDead(PlayerId()) then
				if GetEntityHealth(XOA9) == Yy4GRwpXDb3O61pP and GetEntityHealth(XOA9) ~= tr0oVKfP8ketBijKuzv[21] then
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[291], tr0oVKfP8ketBijKuzv[292], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[8])
				elseif GetEntityHealth(XOA9) == Yy4GRwpXDb3O61pP - tr0oVKfP8ketBijKuzv[24] then
					SetEntityHealth(XOA9, GetEntityHealth(XOA9) + tr0oVKfP8ketBijKuzv[24])
				end
			end;
			if GetEntityHealth(PlayerPedId()) > LXC.MaxPlayerHealth then
				TriggerServerEvent(tr0oVKfP8ketBijKuzv[293], tr0oVKfP8ketBijKuzv[294], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[8])
			end;
			if GetPlayerInvincible(PlayerId()) then
				TriggerServerEvent(tr0oVKfP8ketBijKuzv[295], tr0oVKfP8ketBijKuzv[296], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[8])
				SetPlayerInvincible(PlayerId(), tr0oVKfP8ketBijKuzv[8])
			end
		end;
		if LXC.ASpectate then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[138])
			if NetworkIsInSpectatorMode() then
				TriggerServerEvent(tr0oVKfP8ketBijKuzv[297])
			end
		end;
		if LXC.ABCmds then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[138])
			for L5khJsAiMKpKWam, vX in ipairs(GetRegisteredCommands()) do
				for w5, E8a4tG9x6OBIvnBR_ut in ipairs(BlacklistedCmdsxd) do
					if vX.name == E8a4tG9x6OBIvnBR_ut then
						TriggerServerEvent(tr0oVKfP8ketBijKuzv[298], tr0oVKfP8ketBijKuzv[299], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
					end
				end
			end
		end;
		if LXC.ABlips then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[138])
			local xYVhjptuuo = tr0oVKfP8ketBijKuzv[21]
			local zz6LpCacIYeVdF = GetActivePlayers()
			for i = tr0oVKfP8ketBijKuzv[1], #zz6LpCacIYeVdF do
				if i ~= PlayerId() then
					if DoesBlipExist(GetBlipFromEntity(GetPlayerPed(i))) then
						xYVhjptuuo = xYVhjptuuo + tr0oVKfP8ketBijKuzv[1]
					end
				end;
				if xYVhjptuuo > tr0oVKfP8ketBijKuzv[21] then
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[300])
				end
			end
		end;
		if LXC.ABWeapons then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[301])
			for SycCKlSRBUUXIL, oO1cEZVi2SDYlPJI in ipairs(LXC.ABWeps) do
				Wait(tr0oVKfP8ketBijKuzv[1])
				if HasPedGotWeapon(PlayerPedId(), GetHashKey(oO1cEZVi2SDYlPJI), tr0oVKfP8ketBijKuzv[8]) == tr0oVKfP8ketBijKuzv[1] then
					RemoveWeaponFromPed(PlayerPedId(), GetHashKey(oO1cEZVi2SDYlPJI))
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[302], tr0oVKfP8ketBijKuzv[303]..oO1cEZVi2SDYlPJI, LXC.ABWeaponsKick, tr0oVKfP8ketBijKuzv[8])
				end
			end
		end;
		if LXC.AVD then
			Citizen.Wait(LXC.AutomaticDeleteTimeout)
			for t8C in EnumerateVehicles() do
				for Q3, BWtCSH in pairs(LXC.BModels) do
					if IsVehicleModel(t8C, BWtCSH) then
						SetEntityAsMissionEntity(GetVehiclePedIsIn(t8C, tr0oVKfP8ketBijKuzv[2]), tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
						DeleteEntity(GetVehiclePedIsIn(t8C, tr0oVKfP8ketBijKuzv[2]))
						SetEntityAsMissionEntity(t8C, tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
						DeleteEntity(t8C)
					end
				end
			end
		end;
		if LXC.APD then
			Citizen.Wait(LXC.AutomaticDeleteTimeout)
			objst = tr0oVKfP8ketBijKuzv[21]
			for FBnn9lDDhV in EnumerateObjects() do
				for l, TsVZh4 in pairs(LXC.BEntities) do
					if GetEntityModel(FBnn9lDDhV) == GetHashKey(TsVZh4) or GetEntityModel(FBnn9lDDhV) == TsVZh4 then
						objst = objst + tr0oVKfP8ketBijKuzv[1]
						DeleteEntity(FBnn9lDDhV)
					end
				end
			end
		end;
		if LXC.APD then
			Citizen.Wait(LXC.AutomaticDeleteTimeout)
			PedStatus = tr0oVKfP8ketBijKuzv[21]
			for pErU in EnumeratePeds() do
				for uPrksrxYFm_iZmcmbk_, ZZFKPmI8ypLzQo0G6 in pairs(LXC.BPeds) do
					if IsPedModel(pErU, ZZFKPmI8ypLzQo0G6) then
						PedStatus = PedStatus + tr0oVKfP8ketBijKuzv[1]
						RemoveAllPedWeapons(pErU, tr0oVKfP8ketBijKuzv[2])
						DeleteEntity(pErU)
					end
				end
			end
		end;
		if LXC.ABCmdsGlobal then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[3])
			bcmdnewbeta = #GetRegisteredCommands()
			if Owmie0LlmLIYmSpJeDaO ~= tr0oVKfP8ketBijKuzv[5] then
				if bcmdnewbeta ~= Owmie0LlmLIYmSpJeDaO then
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[304], tr0oVKfP8ketBijKuzv[305], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
				end
			end
		end;
		if LXC.NRCMethod then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[3])
			numero = GetNumResources()
			if zuMYqpy306kfB ~= tr0oVKfP8ketBijKuzv[5] then
				if zuMYqpy306kfB ~= numero then
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[306], tr0oVKfP8ketBijKuzv[307], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
				end
			end
		end;
		if LXC.AVHCMethod then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[138])
			local aBRRkzkwt82YZwRx3A7x = GetVehiclePedIsUsing(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]))
			local UQmXr33Lmtbsv = GetEntityModel(aBRRkzkwt82YZwRx3A7x)
			if IsPedSittingInAnyVehicle(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])) then
				if aBRRkzkwt82YZwRx3A7x == rEcxhXxxekw7S9Bmq and UQmXr33Lmtbsv ~= hmSaoBk4hxXheo4uMkp and hmSaoBk4hxXheo4uMkp ~= tr0oVKfP8ketBijKuzv[5] and hmSaoBk4hxXheo4uMkp ~= tr0oVKfP8ketBijKuzv[21] then
					DeleteVehicle(aBRRkzkwt82YZwRx3A7x)
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[308], tr0oVKfP8ketBijKuzv[309], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
					return
				end
			end;
			rEcxhXxxekw7S9Bmq = aBRRkzkwt82YZwRx3A7x;
			hmSaoBk4hxXheo4uMkp = UQmXr33Lmtbsv
		end;
		if LXC.AModelChanger then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[3])
			local jWQJzf = GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])
			for tXK4BUO, fBzOgYmSzz4RtAbqRSX in pairs(LXC.BPeds) do
				if IsPedModel(jWQJzf, fBzOgYmSzz4RtAbqRSX) then
					TriggerServerEvent(tr0oVKfP8ketBijKuzv[310], tr0oVKfP8ketBijKuzv[311], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
				end
			end
		end;
		if Config.WeaponManipulation then
			Citizen.Wait(tr0oVKfP8ketBijKuzv[3])
			local WxKmnX4od0hkbBLv = GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])
			local YF1bokbjHdU8XQ = GetSelectedPedWeapon(WxKmnX4od0hkbBLv)
			if YF1bokbjHdU8XQ ~= tr0oVKfP8ketBijKuzv[5] then
				local r9AiAWjXBCsakHe1pFdP = math.floor(GetWeaponDamage(YF1bokbjHdU8XQ))
				WeaponDamages = Config.WeaponDamages;
				if Config.AntiDamageChanger then
					if WeaponDamages[YF1bokbjHdU8XQ] and r9AiAWjXBCsakHe1pFdP > WeaponDamages[YF1bokbjHdU8XQ] then
						TriggerServerEvent(tr0oVKfP8ketBijKuzv[312], tr0oVKfP8ketBijKuzv[313]..YF1bokbjHdU8XQ, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
					end
				end;
				if Config.AntiExplosiveWeapons then
					local LrRRggKCGmyKX4SDK = GetWeapontypeGroup(YF1bokbjHdU8XQ)
					local Owuy4Ge = GetWeaponDamageType(YF1bokbjHdU8XQ)
					if LrRRggKCGmyKX4SDK == -tr0oVKfP8ketBijKuzv[314] or LrRRggKCGmyKX4SDK == -tr0oVKfP8ketBijKuzv[315] or YF1bokbjHdU8XQ == -tr0oVKfP8ketBijKuzv[316] then
						if Owuy4Ge ~= tr0oVKfP8ketBijKuzv[24] then
							TriggerServerEvent(tr0oVKfP8ketBijKuzv[317], tr0oVKfP8ketBijKuzv[318]..YF1bokbjHdU8XQ, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
						end
					elseif LrRRggKCGmyKX4SDK == tr0oVKfP8ketBijKuzv[319] or LrRRggKCGmyKX4SDK == -tr0oVKfP8ketBijKuzv[320] or LrRRggKCGmyKX4SDK == tr0oVKfP8ketBijKuzv[321] or LrRRggKCGmyKX4SDK == tr0oVKfP8ketBijKuzv[322] or LrRRggKCGmyKX4SDK == -tr0oVKfP8ketBijKuzv[323] then
						if Owuy4Ge ~= tr0oVKfP8ketBijKuzv[157] then
							TriggerServerEvent(tr0oVKfP8ketBijKuzv[324], tr0oVKfP8ketBijKuzv[325]..YF1bokbjHdU8XQ, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
						end
					end
				end
			end
		end
	end
end)
if LXC.PlayerProtection then
	SetEntityProofs(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8], tr0oVKfP8ketBijKuzv[8])
end;
if LXC.ASpeedHack then
	if not IsPedInAnyVehicle(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1]), tr0oVKfP8ketBijKuzv[1]) then
		if GetEntitySpeed(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])) > LXC.SpeedHackValue then
			if not IsPedFalling(GetPlayerPed(-tr0oVKfP8ketBijKuzv[1])) then
				TriggerServerEvent(tr0oVKfP8ketBijKuzv[326], tr0oVKfP8ketBijKuzv[327], tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[8])
			end
		end
	end
end;
if LXC.RSIMethod then
	AddEventHandler(tr0oVKfP8ketBijKuzv[328], function(Yx1FNzf1WorzEAKm9bR)
		local zamybVL0kdCri4RluKeM = string.len(Yx1FNzf1WorzEAKm9bR)
		local WScIqvCF = string.sub(Yx1FNzf1WorzEAKm9bR, tr0oVKfP8ketBijKuzv[1], tr0oVKfP8ketBijKuzv[1])
		if zamybVL0kdCri4RluKeM >= tr0oVKfP8ketBijKuzv[329] and WScIqvCF == tr0oVKfP8ketBijKuzv[330] then
			TriggerServerEvent(tr0oVKfP8ketBijKuzv[331], tr0oVKfP8ketBijKuzv[332]..Yx1FNzf1WorzEAKm9bR, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
		end
	end)
end;
if LXC.ARRMethod then
	AddEventHandler(tr0oVKfP8ketBijKuzv[333], function(nDilZ6OA_435DQgnxLA)
		TriggerServerEvent(tr0oVKfP8ketBijKuzv[334], tr0oVKfP8ketBijKuzv[335]..nDilZ6OA_435DQgnxLA, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
	end)
end;
if LXC.ARSMethod then
	AddEventHandler(tr0oVKfP8ketBijKuzv[336], function(ZRoHg)
		TriggerServerEvent(tr0oVKfP8ketBijKuzv[337], tr0oVKfP8ketBijKuzv[338]..ZRoHg, tr0oVKfP8ketBijKuzv[2], tr0oVKfP8ketBijKuzv[2])
	end)
end