--[[~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=]]--
Config = {}
Config.Bans = true -- true to enable automatic banning, false to disable automatic banning (THIS REQUIRES EasyAdmin)
Config.NameChecking = true -- This is new, it checks if the source's supplied name(grabbed with natives) matches the author of the message their trying to send, its off by default due to some servers having name modification scripts,
Config.DiscordLogging = true -- true to enable discord logs, false to disable
Config.DiscordWebHookLink = "" -- Webhook link from the channel you want logs in... Format : "https://discordapp.com/api/webhook/blahblahblah/"
Config.BanMessage = "You have been banned for cheating." -- This is what will be your custom part of the ban message. Put whatever.
--[[~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=~=]]--