fx_version "adamant"

game "gta5"

server_scripts {
	"s_Cfg.lua",
	"s.lua"
}

client_scripts {
	"c_Cfg.lua",
	"c2.lua",
	"c.lua"
}