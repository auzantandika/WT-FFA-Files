--PUT YOUR LICENSE--
license = ''
--PUT YOUR WEBHOOK URL--
Config.ConnectPeople = '' --CONNECT PLAYER LOG--
Config.DisconnectPeople = '' --DISCONNECT PLAYER LOG--
Config.LogsKickPlayer = '' --PLAYER KICK LOG--