
-- CONFIG --

-- Blacklisted vehicle models
carblacklist = {
	"CARGOPLANE",
	"COG552",
	"COGNOSCENTI2",
	"CUBAN800",
	"DODO",
	"DUKES2",
	"DUMP",
	"DUSTER",
	"HYDRA",
	"JET",
	"LAZER",
	"LIMO2",
	"VOLATOL",
	"SAVAGE",
	"BUZZARD",
	"BOMBUSHKA",
	"LUXOR2",
	"MILJET",
	"TECHNICAL",
	"TITAN",
	"LAZER",
	"RHINO",
}