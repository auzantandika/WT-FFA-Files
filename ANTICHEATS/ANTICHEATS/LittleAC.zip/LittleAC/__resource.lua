description 'LittleAC'

server_scripts{
	'config.lua',
	'config-s.lua',
	'gbss.lua',
	'tables/blacklistedwords.lua',
	'tables/whitelistexplosions.lua'
} 

client_scripts {
	'config.lua',
	'gbxx.lua',
	--BLACKLIST--
	'tables/blacklistedcars.lua',
	'tables/blacklistedweapons.lua',
	'tables/blacklistedpeds.lua'
}
