FAC.RegisterClientCallback('freedomanticheat:stillAlive', function()
    FAC.TriggerServerEvent('freedomanticheat:stillAlive')
end)
