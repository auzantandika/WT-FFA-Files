FXServer NEW_BANKING

NOTICE: If you edit this script, I will not provide support. I will only provide support for this script in it's unedited state.

[REQUIREMENTS]

Dependencies For Full Functionality

es_extended => https://github.com/TTYY-Org/es_extended



Install To resources/[ttyy]/new_banking << MUST BE INSTALLED HERE


Add this in your server.cfg :
start new_banking

Credits: Script Created By: @onlyserenity(amjedcha)

Licensing: Please do not edit it or post it anywhere else without @onlyserenity's permission. If you have a previous release of this script that contains the license, then you may use that version in any way that you please, but please do not use code from this version to update that version.
